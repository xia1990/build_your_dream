#!/bin/sh
cd C:/Users/dongqinling/Desktop/S200X/251

if [ -f *.txt ];then
mkdir savetxt
cp *.txt savetxt/
rm *.txt
fi

cp Z:/251_QFIL.zip .

unzip 251_QFIL.zip -d S200X_`date +%Y%m%d`
cp V:/临时软件版本/S200X-U100/NOHLOS_20180718/* S200X_`date +%Y%m%d`

cp S200X_`date +%Y%m%d` V:/临时软件版本/S200X-U100/dailybuild_251server/S200X_`date +%Y%m%d` -rf
rm 251_QFIL.zip
#rm S200X_`date +%Y%m%d`.zip