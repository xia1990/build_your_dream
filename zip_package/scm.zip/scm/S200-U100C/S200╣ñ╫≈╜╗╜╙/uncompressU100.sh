#!/bin/sh
cd C:/Users/dongqinling/Desktop/S200X/U100C

if [ -f *.txt ];then
mkdir savetxt
cp *.txt savetxt/
rm *.txt
fi

if [ -d FlashPackage ];then
rm -rf FlashPackage
fi

cp Z:/FlashPackage_S200X-U100C.zip .


unzip FlashPackage_S200X-U100C.zip
#FlashPackage_S200X-U100C.txt
mv ./*.txt FlashPackage_1.tar.gz

tar -xzvf FlashPackage_1.tar.gz

mv FlashPackage.txt FlashPackage.zip

unzip FlashPackage.zip -d FlashPackage

 
mv FlashPackage.zip S200X-U100C_`date +%Y%m%d`.zip

cp S200X-U100C_`date +%Y%m%d`.zip V:/临时软件版本/S200X-U100/dailybuild


mv FlashPackage/ S200X-U100C_`date +%Y%m%d`


rm -rf FlashPackage_S200X-U100C.zip

rm -rf FlashPackage_1.tar.gz
rm -rf S200X-U100C_`date +%Y%m%d`.zip