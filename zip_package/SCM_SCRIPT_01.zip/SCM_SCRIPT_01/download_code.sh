#!/bin/bash
function log(){
    local -r level="$1"
    local -r string="$2"
    local -r time_now=$(date +%Y-%m-%d' '%H:%M:%S)
    case "$level" in  
       "error") echo -e "\e[31m$time_now ERROR: $string\e[0m" ;;
       "info") echo "$time_now INFO: $string" ;;
       "good") echo -e "\e[32m$time_now GOOD: $string\e[0m" ;;
       "notice") echo -e "\e[34m$time_now NOTICE: $string\e[0m" ;;
    esac    
}

function parse_args(){
    project="$1"
    branch="$2"

    project_list=("E300L" "A305" "A306" "A307" "A308" "E26XL")

    E300L_url="ssh://gerritmaster.wind-mobi.com:29418/MSM89XX_P_CODE_SW3/manifest"
    A305_url="ssh://gerritmaster.wind-mobi.com:29418/MSM89XX_P_CODE_SW3/manifest"
    A306_url="ssh://gerritmaster.wind-mobi.com:29418/MSM89XX_P_CODE_SW3/manifest"
    A307_url="ssh://gerritmaster.wind-mobi.com:29418/MSM89XX_P_CODE_SW3/manifest"
    A308_url="ssh://gerritmaster.wind-mobi.com:29418/MSM89XX_P_CODE_SW3/manifest"
    E26XL_url="ssh://gerritmaster.wind-mobi.com:29418/GR6750_66_A_N_ASUS_SW3/tools/manifest"

    E300L_mirror="/EXCHANGE/mirror/MSM89XX_P_MIRROR/"
    A305_mirror="/EXCHANGE/mirror/MSM89XX_P_MIRROR/"
    A306_mirror="/EXCHANGE/mirror/MSM89XX_P_MIRROR/"
    A307_mirror="/EXCHANGE/mirror/MSM89XX_P_MIRROR/"
    A308_mirror="/EXCHANGE/mirror/MSM89XX_P_MIRROR/"
    E26XL_mirror="/EXCHANGE/mirror/E26X_MIRROR_REPO/"

    E300L_branch_list=("qualcomm" "E300L_DEV_BRH" "E300L_FACTORY_BRH")
    A305_branch_list=("qualcomm" "A305_DEV_BRH")
    A306_branch_list=("qualcomm" "A306_DEV_BRH" "A306_FACTORY_BRH")
    A307_branch_list=("qualcomm")
    A308_branch_list=("qualcomm")
    E26XL_branch_list=("master" "E26XL_DEV_BRH")

    if [[ "$project" == "" || "$branch" == "" ]]
    then
        echo ""
        for project_name in "${project_list[@]}"
        do
            echo "$project_name"
        done
        log "notice" "请输入项目名称:"
        read -t 10 project
        [ "$project" == "" ] && log "error" "timeout 20s" && exit 1

        echo ""
        case "$project" in
            E300L)
                for branch_name in "${E300L_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
            A305)
                for branch_name in "${A305_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
            A306)
                for branch_name in "${A306_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
            A307)
                for branch_name in "${A307_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
            A308)
                for branch_name in "${A308_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
            E26XL)
                for branch_name in "${E26XL_branch_list[@]}"
                do
                    echo "$branch_name"
                done
            ;;
        esac
        log "notice" "请输入分支名称:"
        read -t 20 branch
     fi



    project_flag="false"
    branch_flag="false"
    if [[ "$project" != "" || "$branch" != "" ]]
    then
        for project_name in "${project_list[@]}"
        do
             if [ "$project" == "$project_name" ]
             then
                project_flag="true"
                break
             fi
        done
        [ "$project_flag" == "false" ] &&  log "error" "$project not exist!!!!" && exit 1

        if [ "$project_flag" == "true" ]
        then
            case "$project" in 
            E300L|E300|300)
                for branch_name in "${E300L_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in E300L"
                code_url="$E300L_url"
                code_mirror="$E300L_mirror"
            ;;
            A305|305)
                for branch_name in "${A305_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in A305"
                code_url="$A305_url"
                code_mirror="$A305_mirror"
            ;;
            A306|306)
                for branch_name in "${A306_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in A306"
                code_url="$A306_url"
                code_mirror="$A306_mirror"
            ;;
            A307|307)
                for branch_name in "${A307_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in A307"
                code_url="$A307_url"
                code_mirror="$A307_mirror"
            ;;
            A308|308)
                for branch_name in "${A308_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in A308"
                code_url="$A308_url"
                code_mirror="$A308_mirror"
            ;;
            E26XL|E262|E26X|26X)
                for branch_name in "${E26XL_branch_list[@]}"
                do
                    if [ "$branch" == "$branch_name" ]
                    then
                        branch_flag="true"
                    fi
                done
                [ "$branch_flag" == "false" ] && log "error" "$branch BRANCH not exist in A308"
                code_url="$E26XL_url"
                code_mirror="$E26XL_mirror"
            ;;
            esac
        fi
    fi

}

function download_code(){
    [ -d "$code_mirror" ] || log "notice" "请联系SCM部署mirror"
    repo init -u "$code_url"  -m "$branch".xml --reference="$code_mirror"
    repo sync -cj4
    repo start "$branch" --all
}
################
parse_args "$@"
download_code 
