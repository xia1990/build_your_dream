#!/bin/bash

#项目名称
build_param=$1
#要释放的文件名称
release_param=$2
WsRootDir=`pwd`
MY_NAME=`whoami`
OUT_PATH=$WsRootDir"/out/target/product/"$BUILD_FILES


function choose_X100()
{
    BASE_PROJECT_NAME=$build_param
    CUSTOM_MODEM=`cat ./device/ginreen/$build_param/ProjectConfig.mk | grep "^CUSTOM_MODEM" | tail -1 | sed "s/\s*CUSTOM_MODEM\s*=\s*\(.*\)\s*/\1/g"`
    MODEM_LTG_PATH=$CUSTOM_MODEM
    MODEM_LWG_PATH=$CUSTOM_MODEM


    typeset -u PLATFORM
    PLATFORM=`cat ./device/ginreen/$build_param/BoardConfig.mk | grep "^TARGET_BOARD_PLATFORM" | tail -1 | sed "s/\s*TARGET_BOARD_PLATFORM\s*:=\s*\(.*\)\s*/\1/g"`
    echo "Hope PLATFORM = $PLATFORM"

    HARDWARE_VER=`cat ./device/ginreen/$build_param/ProjectConfig.mk | grep "^MTK_CHIP_VER" | tail -1 | sed "s/\s*MTK_CHIP_VER\s*=\s*\(.*\)\s*/\1/g"`
    echo "Hope HARDWARE_VER = $HARDWARE_VER"

    MTK_BRANCH=`cat ./device/ginreen/$build_param/ProjectConfig.mk | grep "^MTK_BRANCH" | tail -1 | sed "s/\s*MTK_BRANCH\s*=\s*\(.*\)\s*/\1/g"`
    echo "Hope MTK_BRANCH = $MTK_BRANCH"

    MTK_WEEK_NO=`cat ./device/ginreen/$build_param/ProjectConfig.mk | grep "^MTK_WEEK_NO" | tail -1 | sed "s/\s*MTK_WEEK_NO\s*=\s*\(.*\)\s*/\1/g"`
    echo "Hope MTK_WEEK_NO = $MTK_WEEK_NO"


    if [ ! -d $OUT_PATH ];then
        echo "ERROR: there is no out path:$OUT_PATH"
        exit 0
    fi

    if [ x"$release_param" = x"all" ]; then
        for i in "$OUT_PATH/obj/ETC/MDDB_InfoCustomAppSrcP_MT6750_S00_MOLY_LR11_*_1_ulwctg_n.EDB_intermediates/MDDB_InfoCustomAppSrcP_MT6750_S00_MOLY_LR11_*_1_ulwctg_n.EDB" ; do
        if [ -f $OUT_PATH/obj/ETC/MDDB_InfoCustomAppSrcP_MT6750_S00_MOLY_LR11_*_1_ulwctg_n.EDB_intermediates/MDDB_InfoCustomAppSrcP_MT6750_S00_MOLY_LR11_*_1_ulwctg_n.EDB ];then
            cp $i  $OUT_PATH/Modem_Database_ulwctg
        fi
        done
        echo "modem_ulwcrg"

        cp "$OUT_PATH/obj/CGEN/APDB_MT6755_"$HARDWARE_VER"_"$MTK_BRANCH"_"$MTK_WEEK_NO"" /$OUT_PATH/AP_Database
    fi

    ALL_RELEASE_FILES="md1arm7.img md1dsp.img md1rom.img md3rom.img logo.bin "$PLATFORM"_Android_scatter.txt preloader_$BASE_PROJECT_NAME.bin AP_Database Modem_Database_ulwctg boot.img secro.img userdata.img devinfo.bin system.img lk.bin recovery.img cache.img trustzone.bin custom.img vmlinux.zip"
    case $release_param in
        all)
            RELEASE_FILES=$ALL_RELEASE_FILES
            ;;
        system)
            RELEASE_FILES="system.img"
            ;;
        boot)
            RELEASE_FILES="boot.img"
            ;;
        lk)
            RELEASE_FILES="lk.bin"
            ;;
        logo)
            RELEASE_FILES="logo.bin"
            ;;
        userdata)
            RELEASE_FILES="userdata.img"
            ;;
        pl)
            RELEASE_FILES="preloader_$BASE_PROJECT_NAME.bin"
            ;;
        none)
            ;;
        *)
            echo "not supported!!"
            exit 1
            ;;
    esac
}

#X100
function release_X100()
{
    #echo "进入release_X100"
    if [ x"$RELEASE_FILES" != x"" ]; then
        if [ ! -f "$OUT_PATH/checklist.md5" ]; then
            echo "/*" >> $OUT_PATH/checklist.md5
            echo "* wind-mobi md5sum checklist" >> $OUT_PATH/checklist.md5
            echo "*/" >> $OUT_PATH/checklist.md5
        fi
        for file in $RELEASE_FILES; do
            if [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ]; then
                cd $OUT_PATH/obj/PACKAGING/target_files_intermediates
            elif [ x"$file" == x"updateA2B.zip" ] || [ x"$file" == x"updateB2C.zip" ] ;then
                cd $WsRootDir
            elif [[ $file = *sign* ]];then
                cd $OUT_PATH/signed_bin/
            else
                cd $OUT_PATH
            fi
            md5=`md5sum -b $file`
            if [ -f "$OUT_PATH/checklist.md5" ]; then
                if [ x"$target_files" != x"" ] && [ x"$file" == x"$target_files" ] ;then
                    line=`grep -n "\-target_files-" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
                elif [ x"$ota_files" != x"" ] && [ x"$file" == x"$ota_files" ] ;then
                    line=`grep -n "\-ota-" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
                else
                    line=`grep -n "$file" $OUT_PATH/checklist.md5 | cut -d ":" -f 1`
                fi
            fi
            if [ x"$line" != x"" ]; then
                sed -i $line's/.*/'"$md5"'/' $OUT_PATH/checklist.md5
            else
                if [ x"$md5" != x"" ];then
                echo "$md5" >> $OUT_PATH/checklist.md5
                fi
            fi
        done
        cd $WsRootDir
        if [ -f "$OUT_PATH/checklist.md5" ]; then
            FILES=$FILES" "$OUT_PATH"/"checklist.md5
        fi
    fi
}
#X100


##########################################
function main(){
    #判断两个参数是否为空
    if [ "$build_param" = " " ];then
        echo "Usage: command [build_param]. e.g. ./release_version E200 xxxxx "
        exit 1
    fi
    
    if [ "$release_param" = " " ];then
        release_param=all
    fi

    #根据项目转换文件夹名
    case $build_param in
	    S102X_32)
		    BUILD_FILES="S102X_32"
		    ;;
        *)
            echo "Unknown Project!!"
            exit 1
            ;;
    esac

    if [ ! -d $OUT_PATH ];then
        echo "ERROR: there is no out path:$OUT_PATH"
        exit 0
    fi

    ALL_RELEASE_FILES="boot.img cache.img emmc_appsboot.mbn mdtp.img persist.img ramdisk.img recovery.img system.img userdata.img factory.img esim.img sdcard.img vendor.img iflytek.img fs_image.tar.gz.mbn.img splash.img useretc.img"

    case $release_param in
        all)
            RELEASE_FILES=$ALL_RELEASE_FILES
            ;;
        system)
            RELEASE_FILES="system.img"
            ;;
        boot)
            RELEASE_FILES="boot.img"
            ;;
        aboot)
            RELEASE_FILES="emmc_appsboot.mbn"
            ;;
        userdata)
            RELEASE_FILES="userdata.img"
            ;;
        *)
            echo "not supported!!"
            exit 1
            ;;
    esac

    if [ x"$build_param" == x"X100" ];then
        choose_X100
    fi

    FILES=""

    for file in $RELEASE_FILES; do
        echo "$file"
        FILES=$FILES" "$OUT_PATH"/"$file
    done

    if [ x"$build_param" == x"X100" ];then
        release_X100
    fi

    echo "start to copy those files to /data/mine/test/MT6572/$MY_NAME"

    cp -rf $FILES /data/mine/test/MT6572/$MY_NAME
    
    echo "Sucess!"
}

######################################################
main()
