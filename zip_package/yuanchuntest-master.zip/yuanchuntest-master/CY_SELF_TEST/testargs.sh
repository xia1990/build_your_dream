#!/bin/bash
readonly SCRIPTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #脚本存放绝对路径
readonly PATHROOT=$(pwd) #当前路径
declare DEFAULT_ORIGIN #xml中默认的origin关键字
declare -a ORIGINARRAY #xml中fetch行中remote="key_world"中的key_world数组，在main中得到
declare -a PULL_BRANCH_ARRAY #存放共仓分支的数组，在parse_options中处理PUBLIC_REPOSITORIES时生成
readonly branch_start='test_xml_start' #拉取共仓分支用于截取的开始标识<!--test_xml_start-->
readonly branch_end='test_xml_end' #拉取共仓分支用于截取的开始标识<!--test_xml_end-->
PUBLIC_REPOSITORIES_MARK="false" #拉取共仓分支的标识，当PULL_BRANCH_MARK PUBLIC_REPOSITORIES XML_START_END_MARK 任意一个不为空，就为true
declare -i FLAG=2 #用来判断共仓分支拉取方式的
if [ -f "/proc/cpuinfo" ]
then
    readonly CPU_CORES=$(grep -c processor /proc/cpuinfo) #cpu核心数，用来拉取代码时 -j多少使用
else
    readonly CPU_CORES=16 #上面失败自定义为16线程
fi

readonly OPTION_VAR_ARRAY=(
    BASE_URL
    MANIFEST_BRANCH
    MANIFEST_XML_NAME_PREFIX
    NEW_BRANCH
    NEW_XML
    PULL_BRANCH_MARK
    PUBLIC_REPOSITORIES
    XML_START_END_MARK
)

source "${SCRIPTDIR}"/commonlibs.sh


function clean_environment(){
    log_info "start to clean environment"
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        unset "$myvar"
    done
}


function parse_options(){
    while [[ $# -gt 1 ]]
    do
        key="$1"
        case $key in
            --base-url)
                BASE_URL="$2" #ssh://代码拉取路径
                if [[ -z "$BASE_URL" || "$BASE_URL" == "" ]] #不能为空
                then
                    log_error "BASE_URL is empty, exit abnormally"
                    exit 1
                fi
                readonly BASE_URL=$(echo "$BASE_URL" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g') #去头尾空格
                is_safe_url "${BASE_URL}"
                if [ $? != 0 ]
                then
                    log_error "base url name not safe: ${BASE_URL}, exit abnormally"
                    exit 1
                fi
                log_info "$BASE_URL"
                ;;
            --manifest-branch)
                MANIFEST_BRANCH="$2" #manifest仓库默认分支
                if [ -z "$MANIFEST_BRANCH" ] #可以为空
                then
                    MANIFEST_BRANCH="master"
                fi
                readonly MANIFEST_BRANCH=$(echo "$MANIFEST_BRANCH" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_name_component "${MANIFEST_BRANCH}"  # HACK, not so precise
                if [ $? != 0 ]
                then
                    log_error "manifest branch name not safe: ${MANIFEST_BRANCH}, exit abnormally"
                    exit 1
                fi
                log_info "$MANIFEST_BRANCH"
                ;;
            --xml-name-prefix)
                MANIFEST_XML_NAME_PREFIX="$2" #不能为空
                if [[ -z "${MANIFEST_XML_NAME_PREFIX}" || "$MANIFEST_XML_NAME_PREFIX" == "" ]]
                then
                    log_error "xml name prefix empty, exit abnormally"
                    exit 1
                fi
                readonly MANIFEST_XML_NAME_PREFIX=$(echo "$MANIFEST_XML_NAME_PREFIX" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_url "${MANIFEST_XML_NAME_PREFIX}" #使用is_safe_url为了可以拉取节点代码
                if [ $? != 0 ]
                then
                    log_error "xml name prefix not safe: ${MANIFEST_XML_NAME_PREFIX}, exit abnormally"
                    exit 1
                fi
                log_info "$MANIFEST_XML_NAME_PREFIX"
                ;;
            --new-branch)
                NEW_BRANCH="$2" #新分支名称
                if [[ -z "$NEW_BRANCH" || "$NEW_BRANCH" == "" ]] #不能为空
                then
                    log_error "NEW_BRANCH is empyt, exit abnormally"
                    exit 1
                fi
                readonly NEW_BRANCH=$(echo "$NEW_BRANCH" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_name_component "${NEW_BRANCH}"
                if [ $? != 0 ]
                then
                    log_error "new branch name not safe: ${NEW_BRANCH},exit abnormally"
                    exit 1
                fi
                log_info "$NEW_BRANCH"
                ;;
            --new-xml)
                NEW_XML="$2" #新清单名称
                if [[ -z "$NEW_XML" || "$NEW_XML" == "" ]] #可以为空
                then
                    readonly NEW_XML="$NEW_BRANCH"
                else
                    readonly NEW_XML=$(echo "$NEW_XML" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                fi
                is_safe_name_component "${NEW_XML}"
                if [ $? != 0 ]
                then
                    log_error "new xml name not safe: ${NEW_XML},exit abnormally"
                    exit 1
                fi
                log_info "$NEW_XML"
                ;;
            --pull-branch-mark)
                PULL_BRANCH_MARK="$2" #数组方式拉取共仓分支true，false标识
                if [ ! -z "$PULL_BRANCH_MARK" ] #可以为空
                then
                    readonly PULL_BRANCH_MARK=$(echo "$PULL_BRANCH_MARK" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                    all_switch "${PULL_BRANCH_MARK}"
                    if [ $? != 0 ]
                    then
                        log_error "public repositories mark not safe: ${PULL_BRANCH_MARK},exit abnormally"
                        exit 1
                    fi
                log_info "$PULL_BRANCH_MARK"
                fi
                ;;
            --public-repositories)
                PUBLIC_REPOSITORIES="$2" #可以存放多个分支的变量，默认中间用空格隔开
                if [[ ! -z "$PUBLIC_REPOSITORIES" ]] #可以为空
                then
                    readonly PUBLIC_REPOSITORIES=$(echo "$PUBLIC_REPOSITORIES" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g'| tr -s ' ') #去除头尾，中间空格
                    local -r index=$(echo "$PUBLIC_REPOSITORIES" | tr -cd ' ' | wc -c) #统计剩余中间空格数
                    readonly index_add_1=$((index+1)) #用awk分隔PUBLIC_REPOSITORIES的域个数
                    for i in $(seq 0 "$((index))")
                    do
                        PULL_BRANCH_ARRAY[$i]=$(echo "$PUBLIC_REPOSITORIES" | awk '{print $'$((i+1))'}') #将变量转换为数组
                    done
                    readonly PULL_BRANCH_ARRAY
                    log_info "${PULL_BRANCH_ARRAY[*]} in array"
                    log_info "$PUBLIC_REPOSITORIES"
                fi
                ;;
           --xml-mark)
                XML_START_END_MARK="$2" #截取方式拉分支true,false标识
                if [ ! -z "$XML_START_END_MARK" ] #可以为空
                then
                    readonly XML_START_END_MARK=$(echo "$XML_START_END_MARK" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                    all_switch "${XML_START_END_MARK}"
                    if [ $? != 0 ]
                    then
                        log_error "xml branch start and end line mark not safe: ${XML_START_END_MARK},exit abnormally"
                        exit 1
                    fi
                    log_info "$XML_START_END_MARK"
                fi
                ;;
        esac
        shift 2
    done
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        eval "[ -z \${${myvar}+x} ]"
        if [ "$?" == 0 ]
        then
           log_error "${myvar} not set, must be given through command line, exit abnormally"
           exit 1
        fi
    done

    if [[ ! -z "$PULL_BRANCH_MARK" || ! -z "$PUBLIC_REPOSITORIES" || ! -z "$XML_START_END_MARK" ]] #共仓任意一个参数不为空，代表拉取共仓分支
    then
        readonly PUBLIC_REPOSITORIES_MARK="true"
    fi

    if [ "$PUBLIC_REPOSITORIES_MARK" == "true" ] #当需要拉取共仓分支的时候
    then
        if [[ ! -z "$PULL_BRANCH_MARK" && ! -z "$PUBLIC_REPOSITORIES" && -z "$XML_START_END_MARK" ]] #PULL_BRANCH_MARK PUBLIC_REPOSITORIES不为空，XML_START_END_MARK为空时
        then
            readonly FLAG=0 #共仓拉取第一种模式
        elif [[ ! -z "$XML_START_END_MARK" ]] #XML_START_END_MARK 不为空
        then
            readonly FLAG=1 #共仓拉分支的第二种模式
        else #剩余的这三个参数组合，全部报错
            log_error "wrong args of PULL_BRANCH_MARK PUBLIC_REPOSITORIES XML_START_END_MARK"
            exit 1
        fi
    fi
}


function main(){
    clean_environment
    parse_options "$@"
}
main $@
