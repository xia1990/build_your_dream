#!/bin/bash
#set -x

####declare variable####
########################

declare -a BranchArray
BranchArray=("xui_project_master") #存放待处理分支


function handle_gongcang(){
    local base_xml=$1
    local flag=$2
    local save=$3
    cp "${base_xml}" change_xml		#cp 先用pushd和popd的进入.repo/manifests
    if [ "${flag}" == "0" ];then                 # 可以采用 if [[ "${flag}" -eq 0 && "${save}" == "true"  ]]
       if [ "${save}" == "true" ];then
          retain_branch
       elif [ "${save}" == "false" ];then
          delete_branch
       else
          echo "wrong save_value input.exit!"
          exit 1
       fi
    elif [ "${flag}" == "1" ];then
      if [ "${save}" == "true" ];then
          dispose_special_format
          retain_format
       elif [ "${save}" == "false" ];then
          dispose_special_format
          delete_format
       else
          echo"wrong save_value input.exit!"
          exit 1
       fi
    else
      echo "wrong flag_value input,exit!"
      exit 1
    fi
}

function delete_branch(){		#删除指定分支
    for branch_name in "${BranchArray[@]}"
     do
       sed -i "/\"${branch_name}\"/d" change_xml
     done
     cp "change_xml" new_manifest
     echo ${new_manifest}
}

function retain_branch(){		#保留指定分支

    if [ -f xmltail ];then
        rm xmltail
    fi

    if [ -f xmlhead ];then
        rm xmlhead
    fi

    #xmlhead="home/xiebingrong/test_for_pullbranch/xmlhead"
    #xmltail="home/xiebingrong/test_for_pullbranch/xmltail"
    for branch_name in "${BranchArray[@]}"
     do
        grep "\"${branch_name}\"" "change_xml" | tee -a "xmltail"
     done

    echo "</manifest>" >> "xmltail"
    default_line=$(grep -n "default" "change_xml" | sed -n '1p'| awk -F":" '{print $1}') #局部变量一律使用local，如果后面只是读取变量。一律改为local -r
    default_line_next=$(( default_line + 1 ))
    sed "${default_line_next},/<\/manifest>/d" "change_xml" | tee "xmlhead"
    cat "xmltail" >> "xmlhead"
    cp "xmlhead" new_manifest
}

function retain_format(){		#保留指定格式内容

    if [ -f xmlhead ];then
            rm xmlhead
    fi

    #xmlhead="home/xiebingrong/test_for_pullbranch/xmlhead"
    default_line=$(grep -n "default" "change_xml" | sed -n '1p'| awk -F":" '{print $1}')
    default_line_next=$(( default_line + 1 ))
    sed "${default_line_next},/<\/manifest>/d" "change_xml" | tee "xmlhead"
    echo "</manifest>" >> "FormatContent"
    cat "FormatContent" >> "xmlhead"
    cp "xmlhead" new_manifest
}

function delete_format(){		#删除指定分支内容
    while read -r line
    do
      line_pre_delete=${line#*\"}
      line_back_delete=${line_pre_delete%%\"*}
      project=${line_back_delete//\//\\\/}
      sed -i "/${project}/d" change_xml
    done < FormatContent
    
    cp "change_xml" new_manifest
}

function dispose_special_format(){		#处理指定格式内容
    StartRowArray=($(grep -n "common_repository_start" "change_xml" | awk -F":" '{print $1}'))
    EndRowArray=($(grep -n "common_repository_end" "change_xml" | awk -F":" '{print $1}'))
    start_line_number=${#StartRowArray[@]}
    end_line_number=${#EndRowArray[@]}

   Details="/home/rlk-buildsrv2/xiebingrong/test_for_pullbranch/Details"
   FormatContent="/home/rlk-buildsrv2/xiebingrong/test_for_pullbranch/FormatContent"
    if [ -f ${Details} ];then
      rm ${Details}
    else
      touch ${Details}
    fi

    if [ -f ${FormatContent} ];then
      rm ${FormatContent}
    else 
      rm ${FormatContent}
    fi

    if [ "${start_line_number}" -ne "${end_line_number}" ]
      then
        echo "start line is not equal end line,exit"
        exit 1
    fi

    for i in $(seq 0 "$(( start_line_number - 1 ))")
     do
         start_number=${StartRowArray[$i]}
         start_number_next=$(( start_number + 1 ))
         end_number=${EndRowArray[$i]}
         if [ "${start_number}" -ge "${end_number}" ]
           then
             echo "end line is not greater than start line"
             exit 1
         fi
         exist_judge=$(sed -n "${start_number_next},${end_number}p" "change_xml" | grep "common_repository_start")
         if [ -n "${exist_judge}" ];then
             echo "format wrong,exit!"
             exit 1
         fi
     sed -n "${start_number},${end_number}p" "change_xml" > ${Details}
     cat ${Details} >>  ${FormatContent}
     rm ${Details}
     done
}

handle_gongcang ~/xiebingrong/manifestfile/qqq/.repo/manifests/XOS_DEV_N.xml $1 $2
