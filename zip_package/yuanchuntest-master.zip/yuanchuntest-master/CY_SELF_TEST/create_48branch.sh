#!/bin/bash
set -x

readonly PATHROOT=$(pwd)
readonly DIRECT_CREATE_BRANCH_SERVICE="192.168.10.48"

judge_48gerrit(){			#判断清单中是否含有48gerrit的仓
    local be_checked_manifest=$1
    if [[ -d "${PATHROOT}/.repo/manifests" ]]
    then
        pushd "${PATHROOT}/.repo/manifests/" > /dev/null
            find48=$(grep "fetch" "$be_checked_manifest" | grep "$DIRECT_CREATE_BRANCH_SERVICE")
            if [[ -z "$find48" || "$find48" == "" ]]
            then
                echo "There is no project in 48gerrit."
            else
                mark_of_48=$(grep "fetch" "$be_checked_manifest" | grep "$DIRECT_CREATE_BRANCH_SERVICE" | grep -aoE 'name="[a-z0-9_]*' | awk -F'"' '{print $2}')
                cp "$be_checked_manifest" "be_changed_manifest.xml"
                create_new_manifest "$mark_of_48" "be_changed_manifest.xml"
            fi
        popd > /dev/null
    else
        echo "wrong pathroot to judge 48gerrit"
        exit 1
    fi
}


create_new_manifest(){			#将不是48gerrit的仓提取出来到新的manifest，48gerrit中的仓也提取出来放到project.list中
    local -r MARK_OF_48=$1
    local -r be_changed_manifest=$2
    default_remote_mark=$(grep "default" "$be_changed_manifest" | grep -aoE 'remote="[a-z0-9_]*' | awk -F'"' '{print $2}') 
    default_line=$(grep -n "default" "$be_changed_manifest" | sed -n '1p'| awk -F":" '{print $1}')
    default_line_next=$(( default_line + 1 ))
    
    sed -n "$default_line_next,/<\/manifest>/p" "${be_changed_manifest}" > "be_settled.txt"
    if [ $? != 0 ]
    then
        echo "failed to create be_settled.txt"
        exit 1
    fi 

    sed "$default_line_next,/<\/manifest>/d" "${be_changed_manifest}" > "head.txt"
    if [ $? != 0 ]
    then
        echo "failed to create head.txt"
        exit 1
    fi

    if [[ "$default_remote_mark" == "$MARK_OF_48" ]]
    then
        grep "remote=" "be_settled.txt" | grep -v "\"$MARK_OF_48\"" >>"head.txt"
        echo "</manifest>" >> "head.txt"
        mv "head.txt" "no_48project.xml"
        grep -v "remote=" "be_settled.txt" | grep "name=" > "project.list"
        grep "remote=" "be_settled.txt" | grep "\"$MARK_OF_48\"" >> "project.list"
    else
        grep -v "\"$MARK_OF_48\"" "be_settled.txt" >> "head.txt"
        mv "head.txt" "no_48project.xml"
        grep "\"$MARK_OF_48\"" "be_settled.txt" | grep "name=" > "project.list" 
    fi

    create_48branch "project.list"
}

create_48branch(){			#根据project.list中的48gerrit仓直接用命令新建分支
    local -r ProjectList=$1
    awk -F'"|"' '{print $2}' < "$ProjectList" > list
    while read -r line
    do
        ssh -p 29418 "$DIRECT_CREATE_BRANCH_SERVICE" gerrit create-branch "${line}" "${NEW_BRANCH}" "${MANIFEST_XML_NAME_PREFIX}" < dev/null
        if [ $? != 0 ]
        then
            echo "failed to create branch in 48gerrit"
            exit 1
        fi
    done < list
   # rm "be_settled.txt" "list" "project.list" "be_changed_manifest.xml"
}

judge_48gerrit "${PATHROOT}/.repo/manifests/A6_XOS_N.xml"
