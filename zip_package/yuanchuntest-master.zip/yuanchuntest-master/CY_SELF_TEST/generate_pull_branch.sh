#!/bin/bash
readonly SCRIPTDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)" #脚本存放绝对路径
readonly PATHROOT=$(pwd) #当前路径
declare DEFAULT_ORIGIN #xml中默认的origin关键字
declare -a ORIGINARRAY #xml中fetch行中remote="key_world"中的key_world数组，在main中得到
declare -a PULL_BRANCH_ARRAY #存放共仓分支的数组，在parse_options中处理PUBLIC_REPOSITORIES时生成
readonly branch_start='test_xml_start' #拉取共仓分支用于截取的开始标识<!--test_xml_start-->
readonly branch_end='test_xml_end' #拉取共仓分支用于截取的开始标识<!--test_xml_end-->
PUBLIC_REPOSITORIES_MARK="false" #拉取共仓分支的标识，当PULL_BRANCH_MARK PUBLIC_REPOSITORIES XML_START_END_MARK 任意一个不为空，就为true
declare -i FLAG=2 #用来判断共仓分支拉取方式的
if [ -f "/proc/cpuinfo" ]
then
    readonly CPU_CORES=$(grep -c processor /proc/cpuinfo) #cpu核心数，用来拉取代码时 -j多少使用
else
    readonly CPU_CORES=16 #上面失败自定义为16线程
fi

readonly OPTION_VAR_ARRAY=(
    BASE_URL
    MANIFEST_BRANCH
    MANIFEST_XML_NAME_PREFIX
    NEW_BRANCH
    NEW_XML
    PULL_BRANCH_MARK
    PUBLIC_REPOSITORIES
    XML_START_END_MARK
)

source "${SCRIPTDIR}"/commonlibs.sh


function clean_environment(){
    log_info "start to clean environment"
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        unset "$myvar"
    done
}


function parse_options(){
    while [[ $# -gt 1 ]]
    do
        key="$1"
        case $key in
            --base-url)
                BASE_URL="$2" #ssh://代码拉取路径
                if [[ -z "$BASE_URL" || "$BASE_URL" == "" ]] #不能为空
                then
                    log_error "BASE_URL is empty, exit abnormally"
                    exit 1
                fi
                readonly BASE_URL=$(echo "$BASE_URL" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g') #去头尾空格
                is_safe_url "${BASE_URL}"
                if [ $? != 0 ]
                then
                    log_error "base url name not safe: ${BASE_URL}, exit abnormally"
                    exit 1
                fi
                log_info "$BASE_URL"
                ;;
            --manifest-branch)
                MANIFEST_BRANCH="$2" #manifest仓库默认分支
                if [ -z "$MANIFEST_BRANCH" ] #可以为空
                then
                    MANIFEST_BRANCH="master"
                fi
                readonly MANIFEST_BRANCH=$(echo "$MANIFEST_BRANCH" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_name_component "${MANIFEST_BRANCH}"  # HACK, not so precise
                if [ $? != 0 ]
                then
                    log_error "manifest branch name not safe: ${MANIFEST_BRANCH}, exit abnormally"
                    exit 1
                fi
                log_info "$MANIFEST_BRANCH"
                ;;
            --xml-name-prefix)
                MANIFEST_XML_NAME_PREFIX="$2" #不能为空
                if [[ -z "${MANIFEST_XML_NAME_PREFIX}" || "$MANIFEST_XML_NAME_PREFIX" == "" ]]
                then
                    log_error "xml name prefix empty, exit abnormally"
                    exit 1
                fi
                readonly MANIFEST_XML_NAME_PREFIX=$(echo "$MANIFEST_XML_NAME_PREFIX" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_url "${MANIFEST_XML_NAME_PREFIX}" #使用is_safe_url为了可以拉取节点代码
                if [ $? != 0 ]
                then
                    log_error "xml name prefix not safe: ${MANIFEST_XML_NAME_PREFIX}, exit abnormally"
                    exit 1
                fi
                log_info "$MANIFEST_XML_NAME_PREFIX"
                ;;
            --new-branch)
                NEW_BRANCH="$2" #新分支名称
                if [[ -z "$NEW_BRANCH" || "$NEW_BRANCH" == "" ]] #不能为空
                then
                    log_error "NEW_BRANCH is empyt, exit abnormally"
                    exit 1
                fi
                readonly NEW_BRANCH=$(echo "$NEW_BRANCH" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                is_safe_name_component "${NEW_BRANCH}"
                if [ $? != 0 ]
                then
                    log_error "new branch name not safe: ${NEW_BRANCH},exit abnormally"
                    exit 1
                fi
                log_info "$NEW_BRANCH"
                ;;
            --new-xml)
                NEW_XML="$2" #新清单名称
                if [[ -z "$NEW_XML" || "$NEW_XML" == "" ]] #可以为空
                then
                    readonly NEW_XML="$NEW_BRANCH"
                else
                    readonly NEW_XML=$(echo "$NEW_XML" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                fi
                is_safe_name_component "${NEW_XML}"
                if [ $? != 0 ]
                then
                    log_error "new xml name not safe: ${NEW_XML},exit abnormally"
                    exit 1
                fi
                log_info "$NEW_XML"
                ;;
            --pull-branch-mark)
                PULL_BRANCH_MARK="$2" #数组方式拉取共仓分支true，false标识
                if [ ! -z "$PULL_BRANCH_MARK" ] #可以为空
                then
                    readonly PULL_BRANCH_MARK=$(echo "$PULL_BRANCH_MARK" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                    all_switch "${PULL_BRANCH_MARK}"
                    if [ $? != 0 ]
                    then
                        log_error "public repositories mark not safe: ${PULL_BRANCH_MARK},exit abnormally"
                        exit 1
                    fi
                log_info "$PULL_BRANCH_MARK"
                fi
                ;;
            --public-repositories)
                PUBLIC_REPOSITORIES="$2" #可以存放多个分支的变量，默认中间用空格隔开
                if [[ ! -z "$PUBLIC_REPOSITORIES" ]] #可以为空
                then
                    readonly PUBLIC_REPOSITORIES=$(echo "$PUBLIC_REPOSITORIES" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g'| tr -s ' ') #去除头尾，中间空格
                    local -r index=$(echo "$PUBLIC_REPOSITORIES" | tr -cd ' ' | wc -c) #统计剩余中间空格数
                    readonly index_add_1=$((index+1)) #用awk分隔PUBLIC_REPOSITORIES的域个数
                    for i in $(seq 0 "$((index))")
                    do
                        PULL_BRANCH_ARRAY[$i]=$(echo "$PUBLIC_REPOSITORIES" | awk '{print $'$((i+1))'}') #将变量转换为数组
                    done
                    readonly PULL_BRANCH_ARRAY
                    for public_branch in "${PULL_BRANCH_ARRAY[@]}"
                    do
                        is_safe_name_component "$public_branch"
                        if [ $? -ne 0 ]
                        then
                            log_error "pulic branch name not safe: ${PUBLIC_REPOSITORIES},exit abnormally"
                            exit 1
                        fi
                    done
                    log_info "${PULL_BRANCH_ARRAY[*]} in array"
                    log_info "$PUBLIC_REPOSITORIES"
                fi
                ;;
           --xml-mark)
                XML_START_END_MARK="$2" #截取方式拉分支true,false标识
                if [ ! -z "$XML_START_END_MARK" ] #可以为空
                then
                    readonly XML_START_END_MARK=$(echo "$XML_START_END_MARK" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                    all_switch "${XML_START_END_MARK}"
                    if [ $? != 0 ]
                    then
                        log_error "xml branch start and end line mark not safe: ${XML_START_END_MARK},exit abnormally"
                        exit 1
                    fi
                    log_info "$XML_START_END_MARK"
                fi
                ;;
        esac
        shift 2
    done
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        eval "[ -z \${${myvar}+x} ]"
        if [ "$?" == 0 ]
        then
           log_error "${myvar} not set, must be given through command line, exit abnormally"
           exit 1
        fi
    done

    if [[ ! -z "$PULL_BRANCH_MARK" || ! -z "$PUBLIC_REPOSITORIES" || ! -z "$XML_START_END_MARK" ]] #共仓任意一个参数不为空，代表拉取共仓分支
    then
        readonly PUBLIC_REPOSITORIES_MARK="true"
    fi

    if [ "$PUBLIC_REPOSITORIES_MARK" == "true" ] #当需要拉取共仓分支的时候
    then
        if [[ ! -z "$PULL_BRANCH_MARK" && ! -z "$PUBLIC_REPOSITORIES" && -z "$XML_START_END_MARK" ]] #PULL_BRANCH_MARK PUBLIC_REPOSITORIES不为空，XML_START_END_MARK为空时
        then
            readonly FLAG=0 #共仓拉取第一种模式
        elif [[ ! -z "$XML_START_END_MARK" ]] #XML_START_END_MARK 不为空
        then
            readonly FLAG=1 #共仓拉分支的第二种模式
        else #剩余的这三个参数组合，全部报错
            log_error "wrong args of PULL_BRANCH_MARK PUBLIC_REPOSITORIES XML_START_END_MARK"
            exit 1
        fi
    fi
}


function get_manifest_ip(){ #获取清单文件里面的IP地址。需要进行检测获取到的ip地址是否正确，没有写完
    if [ -d "$PATHROOT/.repo/manifests" ]
    then
        pushd "$PATHROOT/.repo/manifests"
            local -r sshUrl=$(git remote -v | sed -n "1p" | awk '{print $2}')
            local -r sshUrl_left="${sshUrl##*//}"
            local -r sshUrl_right="${sshUrl_left%/*}"
            echo "$sshUrl_right"
        popd
    fi
}


################################################################
function handle_repository(){
    local LOCAL_MANIFEST_XML_NAME_PREFIX=$1		#待处理清单
    local flag=$2		#有0和1两个选择，该值为0时指定的是处理特定分支，该值为1时指定的是处理特定格式
    local save=$3		#有true和false两个选项，true代表的是保留选定内容，false代表的是删除选定内容
    if [[ -d "${PATHROOT}/.repo/manifests"  ]]
        then
            pushd "$PATHROOT/.repo/manifests/" > /dev/null
                cp "${LOCAL_MANIFEST_XML_NAME_PREFIX}.xml" "change_xml.txt"         #首先将待处理清单复制出来，往后就处理复制出来的文件
                if [[ "${flag}" == "0" && "${save}" == "true" ]]
                then
                    retain_branch                   #如果FLAG=0，save=true，即保留指定分支到新的清单
                elif [[ "${flag}" == "0" && "${save}" == "false" ]]
                then
                    delete_branch                   #如果FLAG=0，save=false，即在新的清单中剔除指定分支
                elif [[ "${flag}" == "1" && "${save}" == "true" ]]
                then
                    dispose_special_format
                    retain_format                   #如果FLAG=1，save=true，即保留指定格式内容到新的清单
                elif [[ "${flag}" == "1" && "${save}" == "false" ]]
                then
                    dispose_special_format
                    delete_format                   #如果FLAG=1，save=false，即在新的清单中剔除指定格式内容
                else
                    echo "wrong save_value input.exit!"
                    exit 1
                fi
            popd > /dev/null
    else
         log_error "wrong pathroot to update repository"
         exit 1
    fi   

}

function delete_branch(){		#删除指定分支
    for branch_name in "${PULL_BRANCH_ARRAY[@]}"
    do
        sed -i "/\"${branch_name}\"/d" "change_xml.txt"
        if [ $? != 0 ]
        then
            log_error "delete branch contain line failed"
             exit 1
        fi
    done
    cp "change_xml.txt" "new_manifest.xml"
    echo "new_manifest.xml"
    SYNC_CODE_XML="new_manifest.xml"
    rm "change_xml.txt"
}

function retain_branch(){		#保留指定分支

    if [[ -f "xmltail.txt" || -f "xmlhead.txt" ]]
    then
        rm "xmltail.txt" "xmlhead.txt"
    fi

    for branch_name in "${PULL_BRANCH_ARRAY[@]}"
    do
        grep "\"${branch_name}\"" "change_xml.txt" | tee -a "xmltail.txt"
        if [ $? != 0 ]
        then
            log_error "delete branch contain line failed"
            exit 1
        fi
    done

    echo "</manifest>" >> "xmltail.txt"
    default_line=$(grep -n "default" "change_xml.txt" | sed -n '1p'| awk -F":" '{print $1}')
    default_line_next=$(( default_line + 1 ))
    sed "${default_line_next},/<\/manifest>/d" "change_xml.txt" | tee "xmlhead.txt"
    cat "xmltail.txt" >> "xmlhead.txt"
    cp "xmlhead.txt" "new_manifest.xml"
    echo "new_manifest.xml"
    SYNC_CODE_XML="new_manifest.xml"
    rm "xmltail.txt" "xmlhead.txt" "change_xml.txt"
}

function retain_format(){		#保留指定格式内容

    if [ -f "xmlhead.txt" ]
    then
        rm "xmlhead.txt"
    fi

    default_line=$(grep -n "default" "change_xml.txt" | sed -n '1p'| awk -F":" '{print $1}')
    default_line_next=$(( default_line + 1 ))
    sed "${default_line_next},/<\/manifest>/d" "change_xml.txt" | tee "xmlhead.txt"
    echo "</manifest>" >> "FormatContent.txt"
    cat "FormatContent.txt" >> "xmlhead.txt"
    cp "xmlhead.txt" "new_manifest.xml"
    echo "new_manifest.xml"
    SYNC_CODE_XML="new_manifest.xml"
    rm "xmlhead.txt" "change_xml.txt" "${FormatContent}"
}

function delete_format(){		#删除指定分支内容
    while read -r line
    do
        line_pre_delete=${line#*\"}
        line_back_delete=${line_pre_delete%%\"*}
        project=${line_back_delete//\//\\\/}
        sed -i "/${project}/d" "change_xml.txt"
        if [ $? != 0 ]
        then
            log_error "delete branch contain line failed"
            exit 1
        fi
    done < "FormatContent.txt"
    cp "change_xml.txt" "new_manifest.xml"
    echo "new_manifest.xml"
    SYNC_CODE_XML="new_manifest.xml"
    rm "change_xml.txt" "${FormatContent}"
}

function dispose_special_format(){		#处理指定格式内容
    StartRowArray=($(grep -n "$branch_start" "change_xml.txt" | awk -F":" '{print $1}'))
    EndRowArray=($(grep -n "$branch_end" "change_xml.txt" | awk -F":" '{print $1}'))
    start_line_number=${#StartRowArray[@]}
    end_line_number=${#EndRowArray[@]}

    Details="$PATHROOT/.repo/manifests/Details.txt"
    FormatContent="$PATHROOT/.repo/manifests/FormatContent.txt"
    
    rm "${Details}" "${FormatContent}"
    touch "${Details}" "${FormatContent}"

    if [ "${start_line_number}" -ne "${end_line_number}" ]
    then
        echo "start line is not equal end line,exit"
        exit 1
    fi

    for i in $(seq 0 "$(( start_line_number - 1 ))")
    do
        start_number=${StartRowArray[$i]}
        start_number_next=$(( start_number + 1 ))
        end_number=${EndRowArray[$i]}
        if [ "${start_number}" -ge "${end_number}" ]
        then
            echo "end line is not greater than start line"
            exit 1
        fi
        exist_judge=$(sed -n "${start_number_next},${end_number}p" "change_xml.txt" | grep "common_repository_start")
        if [ -n "${exist_judge}" ]
        then
            echo "format wrong,exit!"
            exit 1
        fi
     sed -n "${start_number},${end_number}p" "change_xml.txt" > "Details.txt"
     cat "Details.txt" >>  "FormatContent.txt"
     rm "${Details}"
     done
}

##########################################################

function check_disk_space(){
    local -r MOUNT_POINT="$1"
    local -r THRESHOLD=100

    local -r REMAINING_SPACE_G=$(df -BG "${MOUNT_POINT}" | sed -n '2p' | awk '{print $4}' | sed 's/G//g')
    log_info "remaining disk space for ${MOUNT_POINT} is ${REMAINING_SPACE_G}G"
    if [ "${REMAINING_SPACE_G}" -lt "${THRESHOLD}" ]; then
        log_warning "服务器空间不足"
        exit 1
    else
        log_info "服务器空间良好"
    fi
}

function init_manifest(){
    log_info "START INIT MANIFEST NOW"
    repo init -u "$BASE_URL" -b "$MANIFEST_BRANCH" -m "${MANIFEST_XML_NAME_PREFIX}.xml"
    if [ $? != 0 ]
    then
        log_error "init manifest failed"
        exit 1
    fi

}


function sync_code(){
    log_info "START SYNCING CODE NOW"
    local -r SYNC_XML="$1"
    if [[ -d ".repo" && -f ".repo/manifests/${SYNC_XML}" ]]
    then
        repo sync -c -j $CPU_CORES
        if [ $? != 0 ]
        then
            log_error "sync code failed"
            exit 1
        fi
    fi
}


function start_new_branch(){
    local -r BE_STARTED_BRANCH="$1"
    if [[ -z "$BE_STARTED_BRANCH" || "$BE_STARTED_BRANCH" == "" ]]
    then
        log_error "BE_STARTED_BRANCH IS NULL"
        exit 1
    fi
    if repo start "${BE_STARTED_BRANCH}" --all
    then
        log_info "start new branch successful!"
    else
        log_error "start new branch failed!" 31
        exit 1
    fi
}


function push_new_branch(){
    local -r BE_PUSHED_BRANCH="$1"
    if [[ -z "$BE_PUSHED_BRANCH" || "$BE_PUSHED_BRANCH" == "" ]]
    then
        log_error "BE_PUSHED_BRANCH IS NULL"
        exit 1
    fi
    if [[ -d ".repo" ]]
    then
        log_info "repo forall -c 'git push $REPO_REMOTE '$BE_PUSHED_BRANCH''" #outside var
        repo forall -c 'git push $REPO_REMOTE '$BE_PUSHED_BRANCH''
        log_info  "======= push branch now ========"
        if [ $? != 0 ]
        then
            log_error "push branch failed"
            exit 1
        fi
    fi
}


#输出xml默认remote="key_world"，中的key_world
function get_default_origin(){
    local -r XML_FILE="$1"
    if [[ -d ".repo/manifests" && ! -z "$XML_FILE"  ]]
    then
        pushd ".repo/manifests" > /dev/null
            readonly defaultArray=($(sed -n "/default/p" "$XML_FILE")) #得到default那行，默认会以空格隔开作为数组元素
            for str in "${defaultArray[@]}"
            do
                local remote_line=''
                remote_line=$(echo "$str" | grep "remote")
                if [ ! -z "$remote_line" ] #搜索到的话
                then
                    readonly defalut_origin=$(echo "$remote_line" | awk -F '"|"' '{print $2}') #截取出origin关键字
                    echo "$defalut_origin"
                    break
                fi
            done
            if [ -z "$remote_line" ] #空的就报错
            then
                log_error "default remote origin is empty"
                exit 1
            fi
        popd > /dev/null
    else
        log_error "wrong code environment"
        exit 1
    fi
}


#得到xml中fetch行中的remote="key_world"的数组
function get_remote_origins(){
    local -r XML_NAME="$1"
    if [[  -d ".repo/manifests" && ! -z "$XML_NAME" ]]
    then
        pushd ".repo/manifests" > /dev/null
            readonly getfetchArray=($(sed -n "/fetch/p" "$XML_NAME")) #把fetch行放到数组里面，默认空格隔开作为数组元素
            local originArray=()
            local index=0
            for origin in "${getfetchArray[@]}"
            do
                echo "$origin" | grep "name=" > /dev/null #找到name="origin"类似行的话
                if [ $? -eq 0 ]
                then
                    originArray[${index}]=$(echo "$origin" | grep "name=" | awk -F '"|"' '{print $2}') #就把origin截取出来放到数组里面
                    index=$((index+1))
                fi
            done
            if [ "${#originArray[@]}" -eq 0 ] #为空就报错
            then
                log_error "no other remote origin"
                exit 1
            fi
            echo "${originArray[@]}" #输出数组，传递给接收数组
            unset origin

        popd > /dev/null
    else
        log_error "wrong code environment!!!"
        exit 1
    fi
}


#最底层的清单修改函数。会将文件的分支改为最新分支。规范格式。功能上和以前的文件完全相同
function xml_modified(){
    local -r LOCAL_NEW_BRANCH="$1"
    local -r LOCAL_NEW_XML="$2"
    local -r LCOAL_DEFAULT_ORIGIN="$3"
    for origin_local in "${ORIGINARRAY[@]}"
    do
        if [ "$origin_local" != "$LCOAL_DEFAULT_ORIGIN" ]
        then
            sed -n "/remote=\"${origin_local}\"/=" "$LOCAL_NEW_XML" > "${origin_local}.txt" #以fetch中各个origin为文件名，存储各个origin在清单中出现的行号
            sed -i "s/remote*=.*\"${origin_local}\"\ //g" "$LOCAL_NEW_XML" #删除以前的remote="origin" 防止有屌丝格式不规范
        fi
    done
    unset origin_local

    sed -i "s/revision*=.*\".*\"/revision=\"$LOCAL_NEW_BRANCH\"/g" "$LOCAL_NEW_XML" #将所有的分支修改为新分支，防止有屌丝格式不规范的写法
    for origin_local in "${ORIGINARRAY[@]}"
    do
    if [ -f "${origin_local}.txt" ]
    then
        while read -r line
        do
            local cmd="echo $origin_local"
            sed -i "${line}s/\".*\"/& remote=\"$($cmd)\"/g" "$LOCAL_NEW_XML" #按照各个origin存储的行号,插入remote="origin"
        done < "${origin_local}.txt"
    fi
    done
    unset origin_local
}


function formed_xml(){
    local -r XML_PART_1="$1"
    local -r XML_PART_2="$2"
    local -r LOCAL_NEW_XML="$3"
    cat "$XML_PART_1" "$XML_PART_2" > "$LOCAL_NEW_XML" #合并处理
    sed -i "/<\/manifest>/d" "$LOCAL_NEW_XML"
    sed -i "$ a<\/manifest>" "$LOCAL_NEW_XML"
}


#分支数组方式拉取共仓分支的的中间函数
function xml_modified_flag_0(){
    local -r LOCAL_NEW_BRANCH="$1"
    local -r LOCAL_NEW_XML="$2"
    local -r LCOAL_DEFAULT_ORIGIN="$3"
    local -r LOCAL_MARK="$4"
    local index=1
    cp "$LOCAL_NEW_XML" "LOCAL_NEW_XML.xml"
    for branch_local in "${PULL_BRANCH_ARRAY[@]}"
    do
        grep "\"$branch_local\"" "$LOCAL_NEW_XML" >> "branch_local.txt" #提取分支数组中分支的所有行
        sed -i "/\"${branch_local}\"/d" "LOCAL_NEW_XML.xml"
    done
    if [ "$LOCAL_MARK" == "true" ] #flag=0时的分流,共仓数组标识为true
    then
        log_info "只拉取共仓数组部分" #处理branch_local.txt
        xml_modified "$LOCAL_NEW_BRANCH" "branch_local.txt" "$LCOAL_DEFAULT_ORIGIN"
    elif [ "$LOCAL_MARK" == "false" ] #flag=0时的分流,共仓数组标识为false
    then
        log_info "剔除共仓数组部分拉取" #处理branch_local${index}.xml
        xml_modified "$LOCAL_NEW_BRANCH" "LOCAL_NEW_XML.xml" "$LCOAL_DEFAULT_ORIGIN"
    fi
    formed_xml "LOCAL_NEW_XML.xml" "branch_local.txt" "$LOCAL_NEW_XML"
}


function xml_modified_flag_1(){
    local -r LOCAL_NEW_BRANCH="$1"
    local -r LOCAL_NEW_XML="$2"
    local -r LCOAL_DEFAULT_ORIGIN="$3"
    local -r LOCAL_MARK="$4"
    local startArray=($(sed -n "/${branch_start}/=" "$LOCAL_NEW_XML")) #截取标识开始行号数组
    local endArray=($(sed -n "/${branch_end}/=" "$LOCAL_NEW_XML")) #截取标识结束行号数组
    local -r startArrayLen="${#startArray[@]}"
    for index in $(seq 0 "$((startArrayLen-1))")
    do
        sed -n "${startArray[$index]},${endArray[$index]}p" "$LOCAL_NEW_XML" >> "sign_local.txt" #截取所有截取标识内的行
    done
    grep -v -f "sign_local.txt" "$LOCAL_NEW_XML" > "sign_local.xml" #剔除被截取行的清单
    if [ "$LOCAL_MARK" == "true" ]
    then
        log_info "只拉取截取部分"
        xml_modified "$LOCAL_NEW_BRANCH" "sign_local.txt" "$LCOAL_DEFAULT_ORIGIN"
    elif [ "$LOCAL_MARK" == "false" ]
    then
        log_info "剔除截取部分拉取"
        xml_modified "$LOCAL_NEW_BRANCH" "sign_local.xml" "$LCOAL_DEFAULT_ORIGIN"
    fi
    formed_xml "sign_local.xml" "sign_local.txt" "$LOCAL_NEW_XML"
}


#最上层的清单修改函数，底层走向哪种清单修改方式，在这里第一次分流
function xml_ready_to_modified(){
    local -r LOCAL_OLD_XML="${1}.xml"
    local -r LOCAL_NEW_BRANCH="$2"
    local -r LOCAL_NEW_XML="${3}.xml"
    local -r LCOAL_DEFAULT_ORIGIN="$4"
    local -r LOCAL_PUBLIC_REPOSITORIES_MARK="$5"
    local -r LOCAL_MARK="$6"
    if [[ -d "${PATHROOT}/.repo/manifests"  ]]
    then
        pushd "$PATHROOT/.repo/manifests/" > /dev/null
                cp "$LOCAL_OLD_XML" "$LOCAL_NEW_XML"
                if [[ "$LOCAL_PUBLIC_REPOSITORIES_MARK" == "false" ]]
                then
                    log_info "普通拉取分支"
                    xml_modified "$LOCAL_NEW_BRANCH" "$LOCAL_NEW_XML" "$LCOAL_DEFAULT_ORIGIN" #不拉取共仓
                elif [[ "$FLAG" -eq 0 ]]
                then
                    xml_modified_flag_0 "$LOCAL_NEW_BRANCH" "$LOCAL_NEW_XML" "$LCOAL_DEFAULT_ORIGIN" "$LOCAL_MARK" #共仓数组拉取共仓
                elif [[ "$FLAG" -eq 1 ]]
                then
                    xml_modified_flag_1 "$LOCAL_NEW_BRANCH" "$LOCAL_NEW_XML" "$LCOAL_DEFAULT_ORIGIN" "$LOCAL_MARK" #截取拉取共仓
                fi
        popd > /dev/null
    else
        log_error "wrong pathroot to modified xml"
        exit 1
    fi
}


function push_new_xml(){
    local -r LOCAL_NEW_XML="$1"
    local -r LOCAL_MANIFEST_BRANCH="$2"
    local -r LOCAL_NEW_BRANCH="$3"
    if [[ -d "$PATHROOT/.repo/manifests" ]]
    then
        repo manifest -r -o "init_snapshot_for_${LOCAL_NEW_BRANCH}.xml"
        if [ $? -eq 0 ]
        then
            cp "init_snapshot_for_${LOCAL_NEW_BRANCH}.xml" "$PATHROOT/.repo/manifests"
        fi
        pushd "$PATHROOT/.repo/manifests"
            if [ -f "${LOCAL_NEW_XML}.xml" ]
            then
                local -r origin="$(git config branch.default.remote)"
                git pull
                git add "${LOCAL_NEW_XML}.xml"
                git add "init_snapshot_for_${LOCAL_NEW_BRANCH}.xml"
                git clean -dfx
                log_info "git commit -m add $LOCAL_NEW_XML"
                git commit -m  "add ${LOCAL_NEW_XML}.xml"
                log_info "git push $origin HEAD:$LOCAL_MANIFEST_BRANCH"
                git push "$origin" HEAD:"$LOCAL_MANIFEST_BRANCH"
            fi
        popd
    fi
}


function test_pull_branch(){
    local -r LOCAL_NEW_XML="$1"
    if [ -d "$PATHROOT/.repo/manifests" ]
    then
        if repo init -m "${LOCAL_NEW_XML}.xml"
        then
            if repo sync -c -j "$CPU_CORES"
            then
                log_info "test pull new branch successful"
            fi
        fi
    fi
}


function main(){
    clean_environment
    parse_options "$@"
    check_disk_space "/"
    init_manifest
    if [[ "$PUBLIC_REPOSITORIES_MARK" == "true" && "$FLAG" -eq 0 ]]
    then
        log_info "bingrong xml function ,re init -m XXX.xml 0"
        handle_repository "$MANIFEST_XML_NAME_PREFIX" "$FLAG" "$PULL_BRANCH_MARK"
        if [ -f "$PATHROOT/.repo/manifests/new_manifest.xml" ]
        then
            local -r SYNC_CODE_XML="new_manifest.xml"
            repo init -m "$SYNC_CODE_XML"
        else
            log_error "new_manifest.xml not exist"
            exit 1
        fi
    elif [[ "$PUBLIC_REPOSITORIES_MARK" == "true" && "$FLAG" -eq 1 ]]
    then
        log_info "bingrong xml function ,re init -m XXX.xml 1"
        handle_repository "$MANIFEST_XML_NAME_PREFIX" "$FLAG" "$XML_START_END_MARK"
        if [ -f "$PATHROOT/.repo/manifests/new_manifest.xml" ]
        then
            local -r SYNC_CODE_XML="new_manifest.xml"
            repo init -m "$SYNC_CODE_XML"
        else
            log_error "new_manifest.xml not exist"
            exit 1
        fi
    else
        local -r SYNC_CODE_XML="${MANIFEST_XML_NAME_PREFIX}.xml"
        log_info "NOT PUBLIC BRANCH"
    fi
    sync_code "$SYNC_CODE_XML"
    start_new_branch "$NEW_BRANCH"
    push_new_branch "$NEW_BRANCH"
    readonly DEFAULT_ORIGIN=$(get_default_origin "${MANIFEST_XML_NAME_PREFIX}.xml")
    readonly ORIGINARRAY=($(get_remote_origins "${MANIFEST_XML_NAME_PREFIX}.xml"))
    case "$FLAG" in
        0) xml_ready_to_modified "$MANIFEST_XML_NAME_PREFIX" "$NEW_BRANCH" "$NEW_XML" "$DEFAULT_ORIGIN" "$PUBLIC_REPOSITORIES_MARK" "$PULL_BRANCH_MARK"
          ;;
        1) xml_ready_to_modified "$MANIFEST_XML_NAME_PREFIX" "$NEW_BRANCH" "$NEW_XML" "$DEFAULT_ORIGIN" "$PUBLIC_REPOSITORIES_MARK"  "$XML_START_END_MARK"
          ;;
        2) xml_ready_to_modified "$MANIFEST_XML_NAME_PREFIX" "$NEW_BRANCH" "$NEW_XML" "$DEFAULT_ORIGIN" "$PUBLIC_REPOSITORIES_MARK"
          ;;
        *) log_error "wrong value of FLAG: ${FLAG}"
           exit 1
          ;;
    esac
    push_new_xml "$NEW_XML" "$MANIFEST_BRANCH" "$NEW_BRANCH"
    test_pull_branch "$NEW_XML"
}

main "$@"
