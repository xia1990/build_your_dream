#!/bin/bash
#Transsion Top Secret
#  generate_incremental_ota_package.sh: as the name says
#  DO NOT PRINT SMB_PASSWD
#  DO NOT USE ANY smbclient WRITE METHOD HERE

###############################
###### CONSTANTS SECTION ######
###############################
# passed by environment variable, DO NOT UNSET
declare SMB_USER #Jenkins页面定义的变量，脚本里面是可以直接用的。为了维护和看起来方便。才会已参数的形式引入的。
declare SMB_PASSWD #同上。

readonly OPTION_VAR_ARRAY=(
    OTA_TOOLS
    INCREMENTAL_FROM
    BLOCK_MODE
    INPUT_TARGET_FILE
    OUTPUT_OTA_PACKAGE
    DEVICE_SPECIFIC
    PACKAGE_ZIP_FILE_PATH
    MD5SUM_FILE_PATH
    OTA_TEMPDIR
)


########################################
###### FUNCTION DECLARATION SECTION  ###
########################################
function log(){
    local -r MODE=$1
    shift
    echo "$(date '+%Y-%m-%d %H:%M:%S') $MODE: $*"
}


function log_info(){
    log "INFO" "$@"
}


function log_warning(){
    log "WARNING" "$@"
}


function log_error(){
    # NOTICE: when calling log_error, the build process should be regarded as failure
    log "ERROR" "$@"
}


function myrealpath(){
    local -r path="$1"
    if [ ! -z "$path" ]
    then
        python -c "import os; print os.path.abspath('${path}')"
    else
        echo ""
    fi
}


function all_switch(){
    for arg in "$@"
    do
        if [[ "$arg" != "true" && "$arg" != "false" ]]
        then
            return 1
        fi
    done
    return 0
}


function is_safe_path(){
    local -r path="$1"
    python - "${path}" <<EOF
import sys
if len(sys.argv[1]) == 0:
    sys.exit(1)
validchars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+,-./@_'
result = all(c in validchars for c in sys.argv[1])
if result:
    sys.exit(0)
else:
    sys.exit(1)
EOF
    return $?
}

#环境清理，防止变量干扰。
function clean_environment(){
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        unset "$myvar"
    done
}

#新建一个临时的文件夹。在/tmp/下
function make_tempdir(){
    OTA_TEMPDIR="$(myrealpath "$(mktemp -t --directory OTA_TMP_DIR_"$(date +%Y%m%d%H%M)"_XXXXXX)")"
    if [ ! -d "${OTA_TEMPDIR}" ]
    then
        log_error "invalid ota tempdir: ${OTA_TEMPDIR}, exit abnormally"
    fi

    readonly OTA_TEMPDIR
    export OTA_TEMPDIR
}

function parse_arguments(){
    # create OTA_TEMPDIR
    make_tempdir #新建临时文件夹。定义 OTA_TEMPDIR 变量

    while [[ $# -gt 1 ]] #参数个数大于1时
    do
        key="$1"

        case "$key" in
            --block) #对应底层的--block参数，L的项目不要加
                readonly BLOCK_MODE="$2" #定义了全局变量 BLOCK_MODE
                all_switch "${BLOCK_MODE}" #判定这个变量是否合法
                if [ "$?" != 0 ]
                then
                    log_error "--block should be true or false, exit abnormally"
                    exit 1
                fi
                readonly BLOCK_MODE
                ;;
            --device-specific) #对应底层的-s参数
                readonly DEVICE_SPECIFIC="$2" #定义了全局变量 DEVICE_SPECIFIC
                all_switch "${DEVICE_SPECIFIC}" #判定这个变量是否合法
                if [ "$?" != 0 ]
                then
                    log_error "--device-specific should be true or false, exit abnormally"
                    exit 1
                fi
                readonly DEVICE_SPECIFIC
                ;;
            --output-otapackage) #自动生成差分包的路径和名称
                readonly OUTPUT_OTA_PACKAGE=$(myrealpath "$2") #定义全局变量 OUTPUT_OTA_PACKAGE 写死了output/update.zip 得到绝对路径
                is_safe_path "${OUTPUT_OTA_PACKAGE}" #判定路径是否合法
                if [ "$?" != 0 ]
                then
                    log_error "output ota package name not safe: ${OUTPUT_OTA_PACKAGE}, exit abnormally"
                    exit 1
                fi

                if [ -e "${OUTPUT_OTA_PACKAGE}" ] #判定文件是否存在
                then
                    log_error "output ota package already exists: ${OUTPUT_OTA_PACKAGE}, exit abnormally"
                    exit 1
                fi

                local -r outputdir=$(dirname "${OUTPUT_OTA_PACKAGE}") #定义局部变量outputdir 表示ota包存放路径
                if [ ! -d "${outputdir}" ]
                then
                    log_error "invalid directory: ${outputdir}, exit abnormally"
                    exit 1
                fi
                ARCHIVE_DATE="$(date +%Y%m%d%H%M%S)" #归档日期
                PACKAGE_ZIP_FILE_PATH="${outputdir}"/package_"$ARCHIVE_DATE".zip #归档包名称
                MD5SUM_FILE_PATH="${outputdir}"/md5sum #MD5路径
                log_info "otapackage to be generated: ${OUTPUT_OTA_PACKAGE}"
                log_info "md5sum file to be generated: ${MD5SUM_FILE_PATH}"
                log_info "packaged otapackage to be generated: ${PACKAGE_ZIP_FILE_PATH}"

                if [ -e "${PACKAGE_ZIP_FILE_PATH}" ]
                then
                    log_error "packaged ota package already exists: ${PACKAGE_ZIP_FILE_PATH}, exit abnormally"
                    exit 1
                fi
                ;;
            --ota-tools)
                OTA_TOOLS="$2" #定义了全局变量 OTATOOLS存放路径和文件名称
                local -r TEMP=$(echo "$OTA_TOOLS"|sed 's/\\/\//g') #将路径中的windows中\\换成linux下//
                OTA_ARCHIVE_DIR=${TEMP%\/*} #定义全局变量 OTA_ARCHIVE_DIR 将最后一个/及其自后的内容删除，只留下路径名称。
                log_info "OTA_ARCHIVE_DIR  is $OTA_ARCHIVE_DIR"
                if [[ -z "${SMB_USER+x}" || -z "${SMB_PASSWD+x}" ]] #账户密码为空时，报错。
                then
                    log_error "please set --smb-user and --smb-user before --ota-tools, exit abnormally"
                    exit 1
                fi

                # normalize path
                if is_unc_file "${OTA_TOOLS}" #当这是一个linux文件路径的时候
                then
                    if [ -d "${OTA_TEMPDIR}" ] #当新建的临时文件夹存在的时候
                    then
                        pushd "${OTA_TEMPDIR}"
                            copy_unc_file "$OTA_TOOLS"
                            OTA_TOOLS=$(myrealpath "$(get_filename_from_unc_path "$OTA_TOOLS")") #得到当前OTA_TOOLS路径名称
                        popd
                    else
                        log_error "invalid ota tempdir: ${OTA_TEMPDIR}, exit abnormally"
                    fi
                else
                    OTA_TOOLS=$(myrealpath "${OTA_TOOLS}") #处理路径名称
                fi

                # file validation
                if [ ! -f "${OTA_TOOLS}" ] #文件不存在报错
                then
                    log_error "${OTA_TOOLS} file not found, exit abnormally"
                    exit 1
                fi
                log_info "OTA_TOOLS: $(ls -l "${OTA_TOOLS}")"

                readonly OTA_TOOLS
                ;;
            --incremental-from)
                INCREMENTAL_FROM="$2" #定义全局变量 INCREMENTAL_FROM 初始full包路径名称

                if [[ -z "${SMB_USER+x}" || -z "${SMB_PASSWD+x}" ]] #SMB账户密码校验
                then
                    log_error "please set --smb-user and --smb-user before --incremental-from, exit abnormally"
                    exit 1
                fi

                # normalize path
                if is_unc_file "${INCREMENTAL_FROM}" #当这是linux路径时
                then
                    if [ -d "${OTA_TEMPDIR}" ] #如果/tmp/下的临时文件夹存在
                    then
                        pushd "${OTA_TEMPDIR}"
                            copy_unc_file "${INCREMENTAL_FROM}" #复制初始full包
                            FROM_OTA_NAME=$(get_base_ota_name "${INCREMENTAL_FROM}") #得到的是TC包名称，为了归档时重命名使用的。
                            log_info "FROM_OTA_NAME is $FROM_OTA_NAME"
                            INCREMENTAL_FROM=$(myrealpath "$(get_filename_from_unc_path "${INCREMENTAL_FROM}")") #得到tmp下 full包绝对路径
                        popd
                    else
                        log_error "invalid ota tempdir: ${OTA_TEMPDIR}, exit abnormally"
                    fi
                else
                    INCREMENTAL_FROM=$(myrealpath "${INCREMENTAL_FROM}") #得到绝对路径
                fi

                # file validation
                if [ ! -f "${INCREMENTAL_FROM}" ] #文件不存在，报错
                then
                    log_error "${INCREMENTAL_FROM} file not found, exit abnormally"
                    exit 1
                fi
                log_info "INCREMENTAL_FROM: $(ls -l "${INCREMENTAL_FROM}")"

                readonly INCREMENTAL_FROM
                ;;
            --target)
                INPUT_TARGET_FILE="$2" #定义全局变量 INPUT_TARGET_FILE 目标full包路径名称

                if [[ -z "${SMB_USER+x}" || -z "${SMB_PASSWD+x}" ]] #SMB账户密码校验
                then
                    log_error "please set --smb-user and --smb-user before --target, exit abnormally"
                    exit 1
                fi

                # normalize path
                if is_unc_file "${INPUT_TARGET_FILE}" #是linux路径文件
                then
                    if [ -d "${OTA_TEMPDIR}" ] #/tmp下临时文件夹存在
                    then
                        pushd "${OTA_TEMPDIR}"
                            copy_unc_file "${INPUT_TARGET_FILE}" #复制目标full包
                            TARGET_OTA_NAME=$(get_base_ota_name "${INPUT_TARGET_FILE}") #得到目标TC后缀日期以及V字段，用来归档时重名ota包名称
                            log_info "TARGET_OTA_NAME is : ${TARGET_OTA_NAME}"
                            INPUT_TARGET_FILE=$(myrealpath "$(get_filename_from_unc_path "${INPUT_TARGET_FILE}")") #得到当前tmp full包得到绝对路径
                        popd
                    else
                        log_error "invalid ota tempdir: ${OTA_TEMPDIR}, exit abnormally"
                    fi
                else
                    INPUT_TARGET_FILE=$(myrealpath "${INPUT_TARGET_FILE}") #得到绝对路径
                fi

                # file validation
                if [ ! -f "${INPUT_TARGET_FILE}" ] #文件不存在就退出
                then
                    log_error "${INPUT_TARGET_FILE} file not found, exit abnormally"
                    exit 1
                fi
                log_info "INPUT_TARGET_FILE: $(ls -l "${INPUT_TARGET_FILE}")"

                readonly INPUT_TARGET_FILE
                ;;
            *)
                log_error "do not allow non-option command line arguments: $1, exit abnormally"
                exit 1
                ;;
        esac
        shift; shift # past option, do not support regular argument
    done

    # ensure all option variables are initialized
    for myvar in "${OPTION_VAR_ARRAY[@]}" #函数是否初始化判定
    do
        if [ -z "${myvar+x}" ]
        then
           log_error "${myvar} not set, must be given through command line, exit abnormally"
           exit 1
        fi
    done
}

# accept '/' as path delimiter only
function download_from_unc(){
    # NOTICE:
    #     from https://www.samba.org/samba/docs/man/manpages/smbclient.1.html
    #         You can specify file names which have spaces in them by quoting the name with double quotes, for example "a long file name".

    local -r uncfile="$1" #传建立的linux路径
    local -r fname=$(basename "$uncfile") #文件名称
    local -r dname=$(dirname "$uncfile") #路径名称
    # shellcheck disable=SC2034
    local -r index=$(echo "$dname"|grep -aob '/'|sed -n '4p'|cut -d ':' -f1) #获得服务器和归档路径分隔符的位置
    local servicename="${dname:0:index}" #截取到服务器路径名称
    local relativedir="${dname:index+1}" #截取到归档路径名称

    local basecmd #将下面的命令封装在一个数组里面，使用smbclient下载文件。使用账户和密码登录获取，比直接挂载安全
    basecmd=("smbclient" "${servicename}" "-c" "cd \"${relativedir}\"; get \"${fname}\"")
    log_info "execute cmd now: ${basecmd[*]}"
    # do not use -U option to avoid password leak in "ps" output
    # use bash "process substitution" scheme to avoid password leak
    # the password here will not be shown in 'ps' output or any disk files
    "${basecmd[@]}" -A=<(echo -e "username = ${SMB_USER}\npassword = ${SMB_PASSWD}") #执行这个数组里面的命令，并输入账户密码
    return $?
    # yet another solution, not so secure as above:
    #     env USER="${SMB_USER}" PASSWD="${SMB_PASSWD}" "${basecmd[@]}"
}

function get_base_ota_name(){
    local path="$1"
    local -r uncfile=${path//\\/\/} #由window分隔符符替换为linux分隔符
    local -r fname=$(basename "$uncfile") #得到文件名称
    local -r dname=$(dirname "$uncfile") #得到路径名称
    # shellcheck disable=SC2034
    local -r index=$(echo "$dname"|grep -aob '/'|sed -n '4p'|cut -d ':' -f1) #得到第四个文件分隔符的位置
    local servicename="${dname:0:index}" #截取服务器名称
    local relativedir="${dname:index+1}" #截取归档路径名称

    local from_basecmd #将smbclient登录，显示操作,load到数组里
    from_basecmd=("smbclient" "${servicename}" "-c" "cd \"${relativedir}\"; ls Tcard_update*.zip")
    from_tcardname=$("${from_basecmd[@]}" -A=<(echo -e "username = ${SMB_USER}\npassword = ${SMB_PASSWD}"))
    from_tcardname=${from_tcardname#*Tcard_update_} #得到后面的日期和.zip字段
    BASE_OTA_NAME=${from_tcardname%.zip*} #提出.zip字段。只要文件名称
    echo "${BASE_OTA_NAME}"

}

function upload_to_unc(){
    local -r local_file="$1" #本地差分包路径
    local -r unc_dir="$2" #归档路径和新差分包名称
    local -r unc_dir_file=$(basename "$unc_dir") #文件名
    local -r unc_dir_dir=$(dirname "$unc_dir") #路径名
    local -r index=$(echo "$unc_dir_dir"|grep -aob '/'|sed -n '4p'|cut -d ':' -f1) #linux下第四个文件分隔符位置
    local servicename="${unc_dir_dir:0:index}" #截取服务器路径
    local relativedir="${unc_dir_dir:index+1}" #截取归档路径
    local basecmd

    #定义存放smbclient方式防止差分包的数组
    basecmd=("smbclient" "${servicename}" "-c" "cd \"${relativedir}\"; put \"${local_file}\" \"${unc_dir_file}\"")
    log_info "execute cmd now: ${basecmd[*]}"

    "${basecmd[@]}" -A=<(echo -e "username = ${SMB_USER}\npassword = ${SMB_PASSWD}") #执行上面的数组命令，并输入smb账户密码
    return $?
}

#判定一下是不是linux文件路径
function is_unc_file(){
    local path="$1"
    path=$(echo "$path"|sed 's/\\/\//g') #替换
    if [[ ${path:0:1} == '/' && ${path:1:1} == '/' ]] #截取
    then
        return 0
    else
        return 1
    fi
}

#会打印出当前路径的绝对路径，可以用变量直接来接。不必使用$?来接返回值
function get_filename_from_unc_path(){
    local path="$1"
    path=$(echo "$path"|sed 's/\\/\//g') #路径转换为linux路径
    myrealpath "$(basename "$path")" #打印出当前文件绝对路径
}


# copy unc file to current directory
function copy_unc_file(){
    local path="$1"
    path=$(echo "$path"|sed 's/\\/\//g') #路径转换为linux路径

    log_info "$path is in unc form, try to copy to local disk now"
    # normalize path
    local -r localfile=$(get_filename_from_unc_path "$path")
    download_from_unc "$path" #得到OTATOOLS
    if [[ "$?" != 0 || ! -s "$localfile" ]] #没有成功下载，或者文件为空
    then
        log_error "copy $path failed, exit abnormally"
        exit 1
    fi
}

function unzip_ota_tools(){
    log_info "unzip ota tools to ${OTA_TEMPDIR} now"

    unzip "${OTA_TOOLS}" -d "${OTA_TEMPDIR}" #加压OTA_TOOLS包，这个OTA_TOOLS变量已经是/tmp下的那个路径和文件名称了。
}


function parse_ota_tools_dir(){
    log_info "parse ota tools to get necessary information now"

    pushd "${OTA_TEMPDIR}"
        local privatekeys=( $(find "$(pwd)" -name '*.pk8') ) #查找pk8文件，并将结果存放到数组里面
        if [ "${#privatekeys[@]}" != 1 ] #返回了多条结果，报错
        then
            log_error "there is more than one private key in ota tools, exit abnormally"
            exit 1
        fi
        RELEASE_KEY=${privatekeys[0]%*.pk8} #只要pk8的路径名称
        readonly RELEASE_KEY

        OTA_SCRIPT=$(find "$(pwd)" -name ota_from_target_files) #找到ota的编译脚本，diff_gen.sh中也有用到这个脚本
        if [ -z "${OTA_SCRIPT}" ] #为空退出
        then
            log_error "ota_from_target_files not found, exit abnormally"
            exit 1
        fi
        readonly OTA_SCRIPT

        local -r device_specific_script=$(find "$(pwd)" -name mt_ota_from_target_files.py) #找到另一个脚本
        if [[ "${DEVICE_SPECIFIC}" == 'true' && -n "$device_specific_script" ]] #如果开了-s选项并且有上面的脚本
        then
            DEVICE_SPECIFIC_OPTION=("-s" "${device_specific_script%*.py}") #定义了一个存放命令的数组，判定没有.py尾巴这个文件在不在。
        else
            DEVICE_SPECIFIC_OPTION=() #为空喽
        fi
        readonly DEVICE_SPECIFIC_OPTION

        PATH_OPTION=("-p" "$(pwd)/out/host/linux-x86") #在此定义了一个存放命令的数组，检测文件是否是具名管道
        readonly PATH_OPTION

        if [ "${BLOCK_MODE}" == "true" ] #检测--block是否打开
        then
            BLOCK_OPTION=("--block")
        else
            BLOCK_OPTION=()
        fi
        readonly BLOCK_OPTION
    popd
}


function generate_incr_ota_package(){
    log_info "generate incremental ota package now"

    # when searching ota_scatter.txt, the ota script will assume current working directory is above "out"
    pushd "${OTA_TEMPDIR}"
        cmd=("${OTA_SCRIPT}" "-k" "${RELEASE_KEY}" "${DEVICE_SPECIFIC_OPTION[@]}" "${BLOCK_OPTION[@]}" "${PATH_OPTION[@]}" "-i" "${INCREMENTAL_FROM}" "${INPUT_TARGET_FILE}" "${OUTPUT_OTA_PACKAGE}")
        log_info "execute command now: ${cmd[*]}"
        "${cmd[@]}" #做包
        if [[ "$?" != 0 || ! -f "${OUTPUT_OTA_PACKAGE}" ]] #做失败退出
        then
            log_error "make incremental ota package failed, exit"
            exit 1
        fi
    popd
}


# package update.zip and md5sum to package.zip
function package_md5sum(){
    log_info "package md5sum now"

    echo -n "$(md5sum -b "${OUTPUT_OTA_PACKAGE}" | cut -c1-32)" > "${MD5SUM_FILE_PATH}" #MD5记录文件32位唯一的id，为了对比文件有么有变动
    zip --junk-paths "${PACKAGE_ZIP_FILE_PATH}" "${OUTPUT_OTA_PACKAGE}" "${MD5SUM_FILE_PATH}" #将后面两个打包到前面的那个
    if [[ "$?" != 0 || ! -s "${PACKAGE_ZIP_FILE_PATH}" ]]
    then
        log_error "package md5sum failed, exit abnormally"
        exit 1
    else
        log_info "package md5sum suceeded: ${PACKAGE_ZIP_FILE_PATH}"
    fi
}

function archive_ota_package(){
    #local path=$(echo "$ARCHIVE_FILE_PATH"|sed 's/\\/\//g')
    local -r FULL_OTA_NAME=${FROM_OTA_NAME}-${TARGET_OTA_NAME}_${ARCHIVE_DATE} #准备给差分包重命名的变量
    local -r ARCHIVE_FILE_NAME="package-${FULL_OTA_NAME}.zip" #准备给差分包重命名的变量
    local -r ARCHIVE_FILE="$OTA_ARCHIVE_DIR"/"${ARCHIVE_FILE_NAME}" #准备给差分包重命名的变量名称和归档路径
    log_info "ota archive path is: ${ARCHIVE_FILE}"
    upload_to_unc "${PACKAGE_ZIP_FILE_PATH}" "${ARCHIVE_FILE}"
    if [[ "$?" != 0 ]]
    then
        log_error "archive_ota_package failed, exit abnormally"
        exit 1
    else
        log_info "archive_ota_package succeed : ${ARCHIVE_FILE} "
    fi
}


function rint_temp_dir_tree(){
    log_info "tempdir state is as follows:"

    tree -afpsuD "${OTA_TEMPDIR}" #显示临时文件夹文件结构
}


function remove_temp_dir(){
    log_info "remove tempdir to reclaim disk space"
    rm -rvf "${OTA_TEMPDIR}" #清理临时文件夹
}


##################
## MAIN FUNCTION #
##################
function main(){
    clean_environment
    parse_arguments "$@"
    unzip_ota_tools
    parse_ota_tools_dir
    generate_incr_ota_package
    package_md5sum
    archive_ota_package
    print_temp_dir_tree
    remove_temp_dir

    log_info "generate incremental ota package successfully"
    exit 0
}


#################################
######  MAIN CALL SECTION  ######
#################################

main "$@"
