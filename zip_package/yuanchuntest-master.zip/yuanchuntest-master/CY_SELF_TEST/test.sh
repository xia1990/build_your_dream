#!/bin/bash
a=(a b c d e f)
function sendArray(){
echo "$#"
echo "$1"
echo "$2"
declare -a arr
index=0
for arg
do
    arr[$index]="$3"
    index=$((index+1))
    shift
done
echo "${arr[@]}"
}

sendArray "arg1" "arg2" "${a[@]}"
