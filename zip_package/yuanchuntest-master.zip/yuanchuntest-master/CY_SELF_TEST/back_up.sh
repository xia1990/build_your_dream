#!/bin/bash
#set -x
ALL_START_TIME=$(date +%s)
PWD=$(pwd)
BF=base_file
S_FILE=modified_files
I=0
J=0
exist(){
ls > file_exist.txt
MOD_EXIST=`grep "$S_FILE" file_exist.txt`
rm file_exist.txt
if [ -z  "$MOD_EXIST" ]
then
	echo "file not exist!"
	echo "please check the environment"
	exit 1
fi
}

copy_directory_to_bf(){
cd $MOD_EXIST
find ./ ! -path './build_files*' ! -path './frameworks*' ! -path './.git*' -type f > f_s_directory.txt  
find ./ ! -path './build_files*' ! -path './frameworks*' ! -path './.git*' -type d > lujin.txt		
cd ..

if [ -e $BF ];then
	echo "$BF exist,now remove it"
	rm -rf $BF
	mkdir $BF
else
	mkdir $BF
fi

cd $BF	
mv ../$MOD_EXIST/f_s_directory.txt .
mv ../$MOD_EXIST/lujin.txt .

while read line 
do
	mkdir -p $line

done < lujin.txt
}

modified(){
#now we are in base_files
#sed -i "s/.*\/build\//.\/build\//g" wenjian1.txt	
BUILD_INDEX=""
BOOTABLE_INDEX=""
DEVICE_INDEX=""
EXTERNAL_INDEX=""
PACKAGE_INDEX=""
SYSTEM_INDEX=""
VENDOR=""
M_J=0
while read line
do	
	M_I=0
	for str_exist in build bootable device external packages system vendor
	do
		M_I=`expr $M_I + 1`
		case $M_I in
		1)	BUILD_E=`echo $line | grep "$str_exist"`
			if [ ! -z $BUILD_E ];then
				sub_index $line $str_exist
				BUILD_INDEX=$?		
			fi
		;;
		2)	BOOTABLE_E=`echo $line | grep "$str_exist"`
			if [ ! -z $BOOTABLE_E ];then
				sub_index $line $str_exist 
				BOOTABLE_INDEX=$?
			fi
		;;
		3)	DEVICE_E=`echo $line | grep "$str_exist"`
			if [ ! -z $DEVICE_E ];then
				sub_index $line $str_exist 
				DEVICE_INDEX=$?
			fi
		;;
		4)	EXTERNAL_E=`echo $line | grep "$str_exist"`
			if [ ! -z $EXTERNAL_E ];then
				sub_index $line $str_exist 
				EXTERNAL_INDEX=$?
			fi
		;;
		5)	PACKAGE_E=`echo $line | grep "$str_exist"`
			if [ ! -z $PACKAGE_E ];then
				sub_index $line $str_exist 
				PACKAGE_INDEX=$?
			fi
		;;
		6)	SYSTEM_E=`echo $line | grep "$str_exist"`
			if [ ! -z $SYSTEM_E ];then
				sub_index $line $str_exist 
				SYSTEM_INDEX=$?
			fi
		;;
		7)
			VENDOR_E=`echo $line | grep "$str_exist"`
			if [ ! -z $VENDOR_E ];then
				sub_index $line $str_exist
				VENDOR_INDEX=$?
			fi
		;;
		esac
	done

		if [ -z $BUILD_INDEX ];then
			BUILD_INDEX=99999
		fi
		if [ -z $BOOTABLE_INDEX ];then
			BOOTABLE_INDEX=99999
		fi
		if [ -z $DEVICE_INDEX ];then
			DEVICE_INDEX=99999
		fi
		if [ -z $EXTERNAL_INDEX ];then
			EXTERNAL_INDEX=99999
		fi
		if [ -z $PACKAGE_INDEX ];then
			PACKAGE_INDEX=99999
		fi
		if [ -z $SYSTEM_INDEX ];then
			SYSTEM_INDEX=99999
		fi
		if [ -z $VENDOR_INDEX ];then
			VENDOR_INDEX=99999
		fi


	MIN=$BUILD_INDEX
	Arr=(`echo $BUILD_INDEX` `echo $BOOTABLE_INDEX` `echo $DEVICE_INDEX` `echo $EXTERNAL_INDEX` `echo $PACKAGE_INDEX` `echo $SYSTEM_INDEX` `echo $VENDOR_INDEX`)
	for TEST_MIN in ${Arr[@]}
	do	
		if [ $MIN -gt $TEST_MIN ];then
			MIN=$TEST_MIN
		fi
	done
	M_J=`expr $M_J + 1`
	echo "do lujin :$M_J"

	if [ $MIN -eq 99999 -o $MIN -eq 0 ];then
		echo $line >> f_d_directory.txt
		echo "do ******* nothing *******"
	else	
	case $MIN in 
	`echo $BUILD_INDEX`) echo ${line/*\/build\//\.\/build\/} >> f_d_directory.txt
	;;
	`echo $BOOTABLE_INDEX`)	echo ${line/*\/bootable\//\.\/bootable\/} >> f_d_directory.txt
	;;
	`echo $DEVICE_INDEX`) echo ${line/*\/device\//\.\/device\/} >> f_d_directory.txt 
	;;
	`echo $EXTERNAL_INDEX`) echo ${line/*\/external\//\.\/external\/} >> f_d_directory.txt
	;;
	`echo $PACKAGE_INDEX`) 	echo ${line/*\/packages\//\.\/packages\/} >> f_d_directory.txt
	;;
	`echo $SYSTEM_INDEX`) echo ${line/*\/system\//\.\/system\/} >> f_d_directory.txt 
	;;
	`echo $VENDOR_INDEX`) echo ${line/*\/vendor\//\.\/vendor\/} >> f_d_directory.txt
	;;
	*) echo "other"	;;
	esac
	fi
BUILD_INDEX=""
BOOTABLE_INDEX=""
DEVICE_INDEX=""
EXTERNAL_INDEX=""
PACKAGE_INDEX=""
SYSTEM_INDEX=""
VENDOR_INDEX=""

done < f_s_directory.txt
}

update(){
cd ..
cp $BF/f_s_directory.txt .
cp $BF/f_d_directory.txt .
#now we are in source
while read line 
do
	I=`expr $I + 1`
	echo "cp $I files from source to $BF "
	
	sed -n -e "`echo $I`p" f_s_directory.txt > raw.txt
	raw=`cat raw.txt`	
	cp -rf $line $BF/$raw
	if [ $? != 0 ];then
	echo "$line file not exist" >> filenotfound.txt
	fi
done < f_d_directory.txt
echo "achrive successful!"
if [ -f filenotfound.txt ];then
	mv filenotfound.txt $BF
	echo -e  "\033[31msome files can not find in source ,you can see it ==>> $BF/filenotfound.txt\033[0m"
fi
rm -rf f_s_directory.txt f_d_directory.txt raw.txt
cd $BF
rm -rf f_s_directory.txt f_d_directory.txt lujin.txt str.txt
}

sub_index(){
str=$1
sub_str=$2
len=${#str}
echo $str > str.txt
exist=`grep "${sub_str}" str.txt`
if [ -z $exist ];then
	return 99999
fi
str=${str/*$sub_str/\.\/$sub_str}
left_len=`echo ${#str}`
return $index`expr ${len} - ${left_len}`
}

exist
copy_directory_to_bf
modified
update


ALL_END_TIME=$(date +%s)
ALL_DIFF=$(( $ALL_END_TIME - $ALL_START_TIME ))
echo "Spend ${ALL_DIFF} seconds"
#set +x
