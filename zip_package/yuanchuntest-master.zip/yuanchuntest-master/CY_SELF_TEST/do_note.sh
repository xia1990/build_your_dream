#!/bin/bash
readonly FILE_TYPE_ARRAY=('c' 'h' 'cpp' 'java' 'xml')
readonly SECRET_LEVEL_ARRAY=('Transsion Top Secret' 'Transsion Confidential' 'Transsion Internal Use')
readonly c_h_cpp_java_Top_secret_note='/*Transsion Top Secret*/'
readonly c_h_cpp_java_Confidential_note='/*Transsion Confidential*/'
readonly c_h_cpp_java_Internal_note='/*Transsion Internal Use*/'
readonly xml_Top_secret_note='<!--Transsion Top Secret-->'
readonly xml_Confidential_note='<!--Transsion Confidential-->'
readonly xml_Internal_note='<!--Transsion Internal Use-->'
readonly path=$(pwd)
creat_repositoryFile_auto=0
exec 1> >(tee "log.txt") 2>&1


function do_note_for_one_file(){
	local -r file="$1"
	local -r secretGrade="$2"
	local -r file_Type="$3"

#根据文件类型，依次加注释
	case $file_Type in
		c|h|cpp|java) echo ".$file_Type file"
		local -r firstLine=$(sed -n "1p" "$file" | sed -n "/\/*Transsion /"p)
		if [ "$firstLine" == "" ] || [ -z "$firstLine" ];then
			sed -i "1i /*$secretGrade*/" "$file"
		else
			sed -i "1d" "$file"
			sed -i "1i /*$secretGrade*/" "$file"
		fi
		;;
		xml) echo ".xml file"
		local -r xml_encoding=$(sed -n "1,20p" "$file" | sed -n "/ version=".*" encoding=".*"/p")
		if [ "$xml_encoding" == "" ] || [ -z "$xml_encoding" ];then
			sed -i '/<!--Transsion /d' "$file"
			sed -i "1i <!--$secretGrade-->" "$file"
		else
			sed -i '/<!--Transsion /d' "$file"
			sed -i "2i <!--$secretGrade-->" "$file"
		fi
		;;
		*) echo "unknow file type!!!";;
	esac
}


function get_fileName(){
	local -r logLine=$(git log --oneline | wc -l)
#即使git log 报错。logLine 也会等于0
	if [ "$1" == "" ] || [ -z "$1" ];then
		local -r MT_HIOS_XOS=$(git remote -v | grep -e "MT[0-9]" -e "MTK[0-9]" | sed -n "1p" | awk '{print $2}')
		if [ "$MT_HIOS_XOS" == "" ] || [ -z "$MT_HIOS_XOS" ];then
			echo "TRANSSION repository"
			if [ "$logLine" -eq 1 ];then
				echo -e "\e[31monly one line of log!!!\e[0m"
				return
			elif [ "$logLine" -ge 2 ];then
				local -r startCommit=$(git log --format="%H" | tac | sed -n '1p')
			else
				echo -e "\e[31mlog error or no log!!!\e[0m"
				return
			fi
		else
			echo "MTK repository"
			if [ "$logLine" -eq 1 ] || [ "$logLine" -eq 2 ];then
				echo -e "\e[31monly one or two line of log!!!\e[0m"
				return
			elif [ "$logLine" -ge 3 ];then
				local -r startCommit=$(git log --format="%H" | tac | sed -n '2p')
			else
				echo -e "\e[31mlog error or no log!!!\e[0m"
				return
			fi
		fi
	else
		local -r startCommit="$1"
	fi

	if [ "$2" == "" ] || [ -z "$2" ];then
		local -r endCommit="HEAD"
	else
		local -r endCommit="$2"
	fi

#第一次文件过滤。
	fileNameArray=($(git diff --name-status "$startCommit" "$endCommit" | sed "/^D/d" | awk '{print $2}' | grep -e "\.c\>" -e "\.cpp\>" -e "\.h\>" -e "\.java\>" ))
	for filePathAndName in "${fileNameArray[@]}"
	do
		if [ -f "$filePathAndName" ];then
			fileType=$(echo "$filePathAndName" | awk -F "." '{print $NF}')
		else
			echo "$filePathAndName do not exist!!!"
			continue
		fi

#第二次文件过滤,只处理以下几种文件
		case "$fileType" in
			c|h|cpp|java|xml) do_note_for_one_file "$filePathAndName" "${SECRET_LEVEL_ARRAY[0]}" "$fileType" ;;
			*) echo "$fileType other type of file!!!";;
		esac
	done
	unset fileNameArray
}


function process_repositories(){
	local -r repositoryfile="$1"
	if [ -f "${repositoryfile}" ];then
		readarray -t repositoryArray < "${repositoryfile}"
		if [ -d  ".git" ] && [ "$creat_repositoryFile_auto" -eq 1 ];then
			rm -rf ./"$repositoryfile"
		fi
		for repositoryNameAndCommitId in "${repositoryArray[@]}"
		do
			countRaw=$(echo "$repositoryNameAndCommitId" | awk '{print NF}')
			if [ "$countRaw" -eq 1 ];then
				repositoryName="$repositoryNameAndCommitId"
			elif [ "$countRaw" -eq 2 ];then
				repositoryName=$(echo "$repositoryNameAndCommitId" | awk '{print $1}')
				startCommId=$(echo "$repositoryNameAndCommitId" | awk '{print $2}')
			elif [ "$countRaw" -eq 3 ];then
				repositoryName=$(echo "$repositoryNameAndCommitId" | awk '{print $1}')
				startCommId=$(echo "$repositoryNameAndCommitId" | awk '{print $2}')
				endCommitId=$(echo "$repositoryNameAndCommitId" | awk '{print $3}')
			else
				echo "wrong repositories!!!"
			fi

			if [ -d "$repositoryName" ];then
				pushd ./"$repositoryName"
					gitDir=$(git rev-parse --git-dir)
					if [ "$gitDir" == ".git" ];then
						case "$countRaw" in
							1) get_fileName ;;
							2) get_fileName "$startCommId" ;;
							3) get_fileName "$startCommId" "$endCommitId" ;;
						esac
					else
						echo -e "\e[31m $repositoryName is not a git repository!!!\e[0m"
						echo "$repositoryName" >> "$path"/wrong_repositoryName.txt
					fi
				popd
			else
				echo -e "\e[31m $repositoryName is not a directory!!!\e[0m"
				echo "$repositoryName" >> "$path"/wrong_path.txt
			fi
		done
	else
		echo -e "\e[31m 仓库名称文件不存在！！！\e[0m"
		exit 1
	fi
}


function get_repository_file(){
	local -r repositoryFile="$1"
	if [ -f "$repositoryFile" ];then
		echo "$repositoryFile exist,start to do note !!!!"
	else
		if [ -d ".repo" ];then
			repo list -p > "$repositoryFile"
		elif [ -d ".git" ];then
			echo "." > "$repositoryFile"
			creat_repositoryFile_auto=1
		else
			echo -e "\e[31m 仓库名称文件不存在！！！ 请将脚本在repo代码环境或者单库下执行！！！\e[0m"
			exit 1
		fi
	fi
}


#########################
######### main ##########
#########################
get_repository_file "repository.txt"
process_repositories "repository.txt"
