#!/bin/bash
#this shell make repo code by cory

branchName="L8lite_H808_HIOS1.0_M"
projectName="l8lite_h808_a1"
archiveDirectory="/北京合作项目/L8LITE-H808"
manifestDirectory="h808_release_tag"
#lastDay=${date +%Y%m%d }
lastDay=$(date +%Y%m%d -d "yesterday")
snapTime=$(date +%Y%m%d%H%M)
pathRoot=$(pwd)
archiveTime=$(date +%Y.%m.%d)
archiveTimeSecond=$(date +%Y.%m.%d.%M)
version=
readonly BASE_URL=ssh://192.168.10.40/MTK6580/manifest
readonly MANIFEST_BRANCH=master


checkenv()
{
    local SPACE=`df -h /dev/sda1 | sed -n '2p' | awk '{print $4}' | sed 's/G//g' `
    echo "compile_device space is ${SPACE}"
    if [ ${SPACE} -lt 100 ]; then
        echo -e "编译服务器空间不足"
    else
        echo -e "编译服务器空间良好"
    fi

        local SPACE=`df -h /mnt/SwVer3 | sed -n '2p' | awk '{print $4}' | sed 's/G//g' `
    echo "compile_device space is ${SPACE}"
    if [ ${SPACE} -lt 100 ]; then
        echo -e "版本归档服务器空间不足"
    else
        echo -e "版本归档服务器空间良好"
    fi
}



function update(){
#clean out the workspace and update the work
#	rm -rf .* ./* 
	
#	repo init -u ${BASE_URL} -b ${MANIFEST_BRANCH} -m $branchName.xml
#        repo sync  -c -j32
	repo start $branchName --all
#	repo sync -c 2>&1 | tee sync.log.txt
}

function modifyVersion(){
# add software version modify
cd rlk_projects/$projectName
sed -i "/MTK_BUILD_VERNO/s/[0-9]\{8\}/$lastDay/" ProjectConfig.mk
git add .
git commit -m " update version"
git pull --rebase
originBranch=`git config branch.$branchName.merge`
git push origin HEAD:$originBranch
cd $pathRoot
}

function modifyAppVersion(){
today=`date +%Y%m%d`
cd ../RLK_UTIL
git reset --hard && git clean -dfx
git pull --rebase
cd -
cp ../RLK_UTIL/version_fix .

if [ -f path_not_found.txt ];then
	rm -rf path_not_found.txt
fi

while read line 
do
        if [ -d ./$line ];then
        cd ./$line
        else
        echo $line >> path_not_found.txt
        continue
        fi
        if [ -e AndroidManifest.xml ];then
        versionName=`grep "android:versionName" AndroidManifest.xml`
        versionName_del_space=`echo ${versionName// /;}`        #使用; 替换上个字段中的空格，防止下面的判断中出现多个参数的错误 
        if [ ! -z  $versionName_del_space ];then
                version_del_last=`echo ${versionName_del_space%\"*}` #删除最后一个双引号之后的内容
                version_no=`echo ${version_del_last//\"}` #去掉双引号
                version_id_0=`echo ${version_no##*android:versionName=}` #去掉android:versionName=及其之前的字段，防止其他内容和android:versionName 同时出现在一行的情况， 只剩余版本字段
                version_id=`echo ${version_id_0//;/ }`  #将; 号换成空格，回复原来的格式
                echo "#############  $version_id  #########"
                version_last_no=`echo ${version_id##*\.}` #删除最后一个 “.” 之前的字段，也删除最后一个“.”
                version_last_no_nodate=`echo ${version_id%\.*}` #获取最后一个点之前字段，不包含那个点
                echo "here"
                len=`echo ${#version_last_no}`
                if [ $len -eq 8 ];then
#                        sed -n "s/android:versionName=\".*\"/android:versionName=\"$version_last_no_nodate\.$today\"/" AndroidManifest.xml
                       sed -i "s/android:versionName=\".*\"/android:versionName=\"$version_last_no_nodate\.$today\"/" AndroidManifest.xml      
                else
#                        sed -n "s/android:versionName=\".*\"/android:versionName=\"$version_id\.$today\"/" AndroidManifest.xml
                       sed -i "s/android:versionName=\".*\"/android:versionName=\"$version_id\.$today\"/" AndroidManifest.xml
                fi
        fi
        fi
        cd -
done < version_fix

if [ -f version_fix  ];then
	rm -rf version_fix
fi

}

function makeBin(){
#if [ ${WEEKDAY} -eq 0 ];then
#	source rlk_setenv.sh $projectName
#	archiveTime=$(date +%Y.%m.%d)_ENG
#else
#	source rlk_setenv.sh $projectName  user  
#fi
#	source rlk_setenv.sh $projectName
#        archiveTime=$(date +%Y.%m.%d)_ENG

#make -j32 2>&1 | tee build.log

#if [ ${PIPESTATUS[0]}   -ne 0  ]
#then
#echo "error compile"
#java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "编译报错"
#mkdir -p  /mnt/SwVer3/$archiveDirectory/${archiveTime}_error
#cp build.log /mnt/SwVer3/$archiveDirectory/${archiveTime}_error
#exit 1
#fi
#source rlk_setenv.sh $projectName user   &&  make  -j32  otapackage  2>&1 | tee otapackage.log
#if [ ${PIPESTATUS[0]}   -ne 0  ] 
#then
#echo "error compile" 
#java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "编译报错"
#mkdir -p  /mnt/SwVer3/$archiveDirectory/${archiveTime}_error 
#cp build.log /mnt/SwVer3/$archiveDirectory/${archiveTime}_error
#exit 1
#fi
custom=`ls -l  out/target/product/ | awk ' /^d/  {print $NF}'`
version=`grep  "MTK_BUILD_VERNO" rlk_projects/$projectName/ProjectConfig.mk| sed 's/ //g'|sed 's/.*=//g'`
}


function addSnap(){
#add snapshot manifest.xml
versionBase=${version%-*}
snapVersion=$versionBase-$snapTime
repo manifest -r -o $snapVersion.xml
cd .repo/manifests
git pull --rebase
echo ">>>>>>>>>>>>>>>>>>>>>>>1"
if [ ! -d  "$manifestDirectory"    ]
then
mkdir $manifestDirectory
fi
echo ">>>>>>>>>>>>>>>>>>>>>>>2"
#lastSnapXml=$(ls -t $manifestDirectory/$versionBase* | head  -n1)
cp $pathRoot/$snapVersion.xml $manifestDirectory                #h533_release_tag
git add .
git commit -m "add snapshot $snapVersion.xml"
git push origin HEAD:master
echo ">>>>>>>>>>>>>>>>>>>>>>>3"
lastSnapXml=$(git lg | grep $versionBase* | sed -n 2p | awk '{print $6}')
lastSnapxmlPath=$manifestDirectory/$lastSnapXml
cd $pathRoot
}

function archive(){
if [ -e "release"  ]
then
rm -rf ./release
fi
mkdir release

#obtain the version nuber
versionTime=${version##*-}

#KK AP BP
cp ./out/target/product/$custom/obj/CGEN/APDB* ./release
if [ -e ./release/*_ENUM   ]
then
rm ./release/*_ENUM
fi
cp ./out/target/product/$custom/system/etc/mddb/BPLG* ./release

cp ./out/target/product/$custom/boot.img ./release
cp ./out/target/product/$custom/cache.img ./release
cp ./out/target/product/$custom/lk.bin ./release
cp ./out/target/product/$custom/logo.bin ./release
cp ./out/target/product/$custom/*_Android_scatter.txt ./release
cp ./out/target/product/$custom/preloader* ./release
cp ./out/target/product/$custom/recovery.img ./release
cp ./out/target/product/$custom/system.img ./release
cp ./out/target/product/$custom/userdata.img ./release
cp ./out/target/product/$custom/secro.img ./release
cp ./out/target/product/$custom/trustzone.bin ./release
cp ./out/target/product/$custom/kernel ./release
cp ./out/target/product/$custom/MBR* ./release
cp ./out/target/product/$custom/EBR* ./release
cp ~/workspace/RLK_UTIL/CheckSum_Gen.exe ./release
cp ~/workspace/RLK_UTIL/FlashToolLib* ./release
cd ./release
echo "\015" | wine CheckSum_Gen.exe
rm CheckSum_Gen.exe
rm FlashToolLib*
zip -m  $version.zip ./*
echo "============================="
printf "version is $version :\n"
cd -

if [ -e "track"  ]
then
rm -rf ./track
fi
mkdir track
cp ./out/target/product/$custom/obj/KERNEL_OBJ/vmlinux ./track
cp -r  ./out/target/product/$custom/symbols ./track
cp build/target/product/security/platform.pk8 ./track
cp build/target/product/security/platform.x509.pem ./track
cd ./track
zip -m  -r track.zip ./*
cd -

}


function file(){
if [ -d /mnt/SwVer3$archiveDirectory/$archiveTime  ]
then
archiveTime=$archiveTimeSecond
fi
mkdir $archiveTime
cp -r ./release/$version.zip $archiveTime
cp -r ./track/track.zip $archiveTime
cp -r out/target/product/$custom/obj/PACKAGING/target_files_intermediates/*.zip $archiveTime
cp ./out/target/product/$custom/full_$custom*.zip  $archiveTime/Tcard_update_$versionTime.zip
cp ./out/target/product/$custom/system/build.prop ./$archiveTime
#cp -rf $archiveTime /mnt/SwVer3$archiveDirectory
}

function repoLog(){
touch log.txt log_cm
CURRENT_SNAPSHOT=$manifestDirectory/$snapVersion.xml
repo diffmanifests $lastSnapxmlPath ${CURRENT_SNAPSHOT} | awk '{if($3~/^from$/ && $2~/^changed$/ && $5~/^to$/ || $3~/^revision$/ && $2~/^at$/)print}' | awk '{print $1,$4,$6}' > log_cm
sed -i 's/refs\/tags\///g' log_cm
while read line
      do
       t1=`echo "$line" | awk  '{print $1}'`
       t2=`echo "$line" | awk  '{print $2}'`
       t3=`echo "$line" | awk  '{print $3}'`
       echo $t1
       echo $t2
       echo $t3
       cd $t1
       if [ ! -n "$t3" ];then
       git log  ${t2} --pretty="%an|%s" | grep -v "Merge" | awk -F\| '{printf("%-15s\t%s\n",$1, $2) }' >> ${pathRoot}/log.txt
       else
       git log  ${t2}..${t3} --pretty="%an|%s" | grep -v "Merge" | awk -F\| '{printf("%-15s\t%s\n",$1, $2) }' >> ${pathRoot}/log.txt
       fi
       cd ${pathRoot}
done < log_cm
sort -b -f -d -u ${pathRoot}/log.txt -o ${pathRoot}/log.txt

cp log.txt ./$archiveTime
mv $snapVersion.xml ./$archiveTime
cp ./$archiveTime /mnt/SwVer3$archiveDirectory -rf
repo abandon  $branchName
}



function collect_hios_result()
{
cd ${pathRoot}
#now we are in source
cp ./modified_files/source.txt .
cp ./modified_files/dest.txt .

if [ -d "./hios/" ];then
	rm -rf hios/
	git clone ssh://192.168.10.40:29418/hios
else
	git clone ssh://192.168.10.40:29418/hios
fi

I=0
if [ -f cp_filenotfound.txt ];then
	rm -rf cp_filenotfound.txt
fi
while read source 
do
        I=`expr $I + 1`

        sed -n -e "`echo $I`p" dest.txt > raw.txt
        dest=`cat raw.txt`
	echo "cp $I files from $source to $dest "
pwd && sleep 0.1s	
        cp -rf $source $dest
        if [ $? != 0 ];then
        echo "$source file not exist" >> cp_filenotfound.txt
        fi

	cd ${dest}
	if [ $? = 0 ];then	
		find -type l -name "*.so" -exec rm -rf {} \;
		find -type d | tee path_can_not_be_null
	fi
	
	while read path
	do
		cd ${path}
		touch file_must_exist_now
		cd -
	done < path_can_not_be_null	

	rm -rf path_can_not_be_null
	cd ${pathRoot}
		
done < source.txt

cd  ./hios/
echo "now we delete"
find -name "file_must_exist_now" -exec rm -rf {} \;
echo "cp successful!"

cd ../
if [ -f cp_filenotfound.txt ];then
        echo -e  "\033[31msome files can not find in source ,you can see it ==>>cp_filenotfound.txt\033[0m"
fi
pwd
rm raw.txt

cd hios
git add .
git commit -m "add apk"
#git push origin HEAD:master
}

function message(){
linuxWholeDir="$archiveDirectory/$archiveTime"
winWholeDir=$(echo $linuxWholeDir | tr '/' '\\')
echo -e "\033[31mVersion: $version\033[0m"
echo -n -e '\033[31mArchiveDirectory: \\\\192.168.1.75\SwVer3'
echo -e "\033[31m$winWholeDir\033[0m"
java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "Version: $version
ArchiveDirectory: \\\\192.168.1.75\SwVer3$winWholeDir"
}

#checkenv
#update
#modifyVersion
#modifyAppVersion
#makeBin
#addSnap
#archive
#file
#repoLog
#imessage
collect_hios_result
