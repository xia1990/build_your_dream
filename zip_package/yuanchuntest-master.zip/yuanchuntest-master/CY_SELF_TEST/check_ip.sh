#!/bin/bash
function checkIPAddr(){
    local -r TEST_IP="$1"
    echo "$TEST_IP" | grep "^[0-9]\{1,3\}\.\([0-9]\{1,3\}\.\)\{2\}[0-9]\{1,3\}$" > /dev/null
    if [ $? -ne 0 ]
    then
        return 1
    fi
    local -r ip_part_1=$(echo "$TEST_IP"|awk -F . '{print $1}')
    local -r ip_part_2=$(echo "$TEST_IP"|awk -F . '{print $2}')
    local -r ip_part_3=$(echo "$TEST_IP"|awk -F . '{print $3}')
    local -r ip_part_4=$(echo "$TEST_IP"|awk -F . '{print $4}')
    for num in "$ip_part_1" "$ip_part_2" "$ip_part_3" "$ip_part_4"
    do
        if [ "$num" -gt 255 ] || [ "$num" -lt 0 ]
        then
            return 1
        fi
    done
    return 0
}
