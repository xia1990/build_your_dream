#!/bin/bash
wkvnumber=0
failnumber=0
basetime=0
dailynumber=0
dailyfailnumber=0
failrate=0
weekDay=`date +%w`
JINZHI=1024
KONGZHI=2
function echo_output(){
	string=$1
	color=$2
	if [ -z ${color} ];then
		color=32
	fi

	echo -e "\e[${color}m${string}\e[0m"
}

function count_falirate(){
	if [ ${weekDay} -eq ${KONGZHI} ];then
		for i in `seq 0 6`
		do 

#			basetime=`date +"%Y.%m.%d" -d "-n $i days ago"`
			basetime=`date +"%Y.%m.%d" -d "$i days ago"`
			dailynumber=`find /mnt/SwVer -name "$basetime*" | wc -l`
			dailyfailnumber=`find /mnt/SwVer -name "$basetime*" | grep -E "error|fail" | wc -l`
			wkvnumber=$((${dailynumber}+${wkvnumber}))
			failnumber=$((${failnumber}+${dailyfailnumber}))

			echo_output "date: $basetime successful:  $dailynumber failed: $dailyfailnumber count_successful: $wkvnumber  count_failed:  $failnumber"
		done
			failrate=`awk 'BEGIN{printf "%.1f%%\n",('$failnumber'/'$wkvnumber')*100}'`

			echo_output "\n本周release版本数量${wkvnumber}个，失败数量${failnumber}个,版本失效率${failrate}\n"
	else
		echo_output "今天不需要统计-----happy----"
	fi
}

function read_file(){
file=$1
size=0
countSize=0
while read raw
do	
	size_G=`du -sh $raw | awk '{print $1}' | grep "G\>"`
	size_M=`du -sh $raw | awk '{print $1}' | grep "M\>"`
	size_K=`du -sh $raw | awk '{print $1}' | grep "K\>"`
	if [ ! -z ${size_G}  ];then
		size=`echo $size_G | sed 's/G//g'`
	elif [ !-z ${size_M} ];then
		size=`echo $size_M | sed 's/M//g'`
		size=`echo "scale=2;${size}/${JINZHI}"|bc`
		
	else
		size=`echo $size_K | sed 's/K//g'`
		size=`echo "scale=2;${size}/${JINZHI}/${JINZHI}"|bc`
	fi
	countSize=`echo $size+$countSize|bc`
done < $file
}

function count_size(){
total_countSize=0
oneday_countSize=0
if [ ${weekDay} -eq ${KONGZHI} ];then
	for j in `seq 0 6`
	do
		dateTime=`date +"%Y.%m.%d" -d "$j days ago"`
		find /mnt/SwVer/ -type d -name "$dateTime" > dateTime.txt
		read_file dateTime.txt
		oneday_countSize=$countSize
		echo_output "date: $dateTime size:  ${oneday_countSize}G " "31"
		total_countSize=`echo $oneday_countSize+$total_countSize|bc`
	done
	echo_output "\n本周SwVer上的版本共计 ${total_countSize}G" "31"
else
	echo_output "今天不需要统计-----happy----"
fi

}

function clear_source(){
        if [ -f "dateTime.txt" ];then
		rm -rf dateTime.txt
	fi
}

########################################
#	     main function	       #
########################################

echo_output "########################welcome to use this shell script######################\n"

count_falirate
#set -x
count_size

clear_source
#set +x
