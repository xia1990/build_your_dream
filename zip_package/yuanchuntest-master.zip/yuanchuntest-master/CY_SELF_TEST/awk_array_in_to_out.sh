#!/bin/bash
#set -x
a=(1 2 3)
string="hello#world#test"
ar="ar"
len=`echo ${#a[@]}`
for i in `seq 1 $len`
do	
        echo $i 
        a[$i]=`awk 'BEGIN{split("'$string'",ar,"#");print ar["'$i'"]}'`
        echo ${a[$i]}
done
#set +x
