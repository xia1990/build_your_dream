#!/bin/bash
CODE_PATH=$(pwd)
PATCH_DIR="PATCH_DIR"
function my_exit(){
echo "you enter ctrl+c,please enter y to exit or n to continue!!!"
read -r ANS

case $ANS in
        y|yes|Yes|YES) exit 1 ;;
        n|no|No|NO);;
	*)exit 1;;
esac
}

trap "my_exit" 2

function dir_exist_or_not(){
local local_dir="$1"
local delete_not="${2}"

if [ -d "${local_dir}" ] && [ "${delete_not}" == "yes" ];then
	rm -rf "${local_dir}"
	mkdir -p "${local_dir}"
else
	mkdir -p "${local_dir}"
fi
}

function file_exit_or_not(){
COMMAND="${1}"
FILE_NAME=$(echo "${COMMAND}" | awk -F "=" '{print $2}')

if [ -f "${FILE_NAME}" ];then
	eval "${COMMAND}"

else
	echo -e "\e[31m ${FILE_NAME} not exist !!! \e[0m"
        exit 1
fi
}

function get_bug_project_and_commit_id(){
file_exit_or_not "PATCH_FILE=patch.txt"
readarray -t patchArray < "${PATCH_FILE}"
for patch_number in ${patchArray[*]}
do
	repo forall -pc git log --grep "$patch_number" --format="%H" >> patch_log_file.txt
done

file_exit_or_not "PATCH_LOG_FILE=patch_log_file.txt"
}

function ready_do_patch(){
local -r project_name=$(grep "project" "${LOCAL_PROJECT_LOG}" | awk '{print $2}')
sed -n "2,$"p "${LOCAL_PROJECT_LOG}" > local_commit.txt
file_exit_or_not "LOCAL_COMMIT=local_commit.txt"
readarray -t commitArray < "${LOCAL_COMMIT}"
local path=${project_name%\/*}

if [ -d "${path}" ];then
	pushd ./"${path}" > /dev/null
		echo -e "\e[32mwe now at $project_name\e[0m"
        	for commit_id in ${commitArray[*]}
	        do
        		local path=${project_name%\/*}
			parentsCommitId=$(git log "${commit_id}" --format=raw -1 | grep "parent" | awk '{print $2}')
			do_patch "${commit_id}" "${path}" "${parentsCommitId}"
        	done
	popd > /dev/null
else
	echo "${path} is not a directory!!!"
	exit 1
fi
}

function deal_with_patch_log_file(){
grep -n "project" "${PATCH_LOG_FILE}" | awk -F":" '{print $1}' >  project_line_number.txt
file_exit_or_not "PROJECT_LINE_NUMBER=project_line_number.txt"
local -r count_line_number=$(wc -l "${PROJECT_LINE_NUMBER}" | awk '{print $1}')
readarray -t lineNumberArray < "${PROJECT_LINE_NUMBER}"
local index=1
for line_number in ${lineNumberArray[*]}
do
	local next_index=0
	if [ "${index}" -eq "${count_line_number}" ];then
		start_line=$(sed -n "${index}"p "${PROJECT_LINE_NUMBER}")
		sed -n "${start_line},$"p patch_log_file.txt > local_project_log.txt
		file_exit_or_not "LOCAL_PROJECT_LOG=local_project_log.txt"
		ready_do_patch
	else		
		start_line=$(sed -n "${index}"p "${PROJECT_LINE_NUMBER}")
		next_index=$((index + 1))
		end_line_add_1=$(sed -n "${next_index}"p "${PROJECT_LINE_NUMBER}")
		local end_line=$((end_line_add_1 - 1))
		sed -n "${start_line},${end_line}"p patch_log_file.txt > local_project_log.txt
		file_exit_or_not "LOCAL_PROJECT_LOG=local_project_log.txt"
		ready_do_patch
	fi
	index=$((index + 1))
	echo "${line_number}" > /dev/null
done
}
function clear_txt(){
TYPE="${1}"

if [ "${TYPE}" == "b" ];then
	if [ -d ".repo" ];then
		rm patch_log_file.txt
		rm local_commit.txt
		rm project_line_number.txt
		rm local_project_log.txt
	else
		echo -e "\e[31m not in the code environment!!!!\e[0m"
		exit 1
	fi
elif [ "${TYPE}" == "c" ];then
	rm patch_message.txt
	rm projectNameExist.txt
else
	echo "${TYPE} illegal!!!"
	exit 1
fi
}
function if_choice_is_b_or_c_sync(){
if [ "${choice}" == "b" ];then
	rm change_file_name.txt
	rm patch_name.txt
elif [ "${choice}" == "c" ];then
	rm change_file_name.txt
	rm patch_name.txt
	
fi
}
function do_patch(){
local commit_id="$1"
local projectName="$2"
local parentsCommitId="$3"
local path=${projectName//\//-}
echo -e "\e[31mwe do patch now!!! commit_id:$commit_id \e[0m"


git format-patch -1 "${commit_id}" > patch_name.txt #sometimes,many patches!!!
if [ $? -ne 0 ];then
	echo -e "\e[31m 没有打出patch\e[0m"
	exit 1
else
	readarray -t patchNameArray < patch_name.txt
	
	for old_patch_name in ${patchNameArray[*]}
	do
        	mv "${old_patch_name}" "${path}-${old_patch_name}"
	done
	dir_exist_or_not "${CODE_PATH}/${PATCH_DIR}/${projectName}/${commit_id}" "yes"
        mv ./*.patch "${CODE_PATH}/${PATCH_DIR}/${projectName}/${commit_id}"
fi
	git diff --name-status "${parentsCommitId}" "${commit_id}" | awk '{print $2}' > change_file_name.txt
	readarray -t changeFileArray < change_file_name.txt
	for new_file_path in ${changeFileArray[*]}
	do
	        local new_file_name=${new_file_path##*/}
		git show "${commit_id}":"${new_file_path}" > "${CODE_PATH}/${PATCH_DIR}/${projectName}/${commit_id}/new-${new_file_name}" 2>&1
		git show "${parentsCommitId}":"${new_file_path}" > "${CODE_PATH}/${PATCH_DIR}/${projectName}/${commit_id}/old-${new_file_name}" 2>&1
	done
if_choice_is_b_or_c_sync
}

function get_gerrit_patch_message(){
local -r gerrit_home="$1"
local -r patch_id="$2"
python - "${gerrit_home}" "${patch_id}" <<EOF
import sys
import os
import json
if len(sys.argv[1]) == 0:
    sys.exit(1)
gerrit_home=sys.argv[1]
patchIdStr=sys.argv[2]
def get_patch_info(GERRIT_HOME,patch_id):
    cmd_str='ssh %s gerrit query --format=JSON --patch-sets change:%s'%(GERRIT_HOME,patch_id)
    process = os.popen(cmd_str)
    output = process.readlines()[0]
    jsn_data = json.loads(output)
    return jsn_data
d=get_patch_info(gerrit_home,patchIdStr)
print d["project"]
print d["branch"]
print d["patchSets"][0]["revision"]
print d["patchSets"][0]["ref"]
print d["patchSets"][0]["parents"][0]
EOF
    return $?
}

function commit_id_exist(){
local -r commit_exist=$(git log --pretty=oneline | grep "${commitID}")

if [ "${commit_exist}" == "" ] || [ -z "${commit_exist}" ];then
	echo -e "\e[35m do not find the commit-id ,we should pull this code !!!!! \e[0m"
	git fetch ssh://"${GERRIT_HOST}":29418/"${projectName}" "${refs_change_id}" > /dev/null
fi
}

function get_changeId_message(){
GERRIT_HOST="${1}"
file_exit_or_not "CHANGE_ID_FILE=change_id.txt"

readarray -t changeIdArray < "${CHANGE_ID_FILE}"
mv "${CHANGE_ID_FILE}" ..
rm -rf ./* ./.*
mv ../"${CHANGE_ID_FILE}" .
for gerrit_change_id in ${changeIdArray[*]}
do
	get_gerrit_patch_message "${GERRIT_HOST}" "${gerrit_change_id}" > patch_message.txt
	if [ $? -eq 0 ];then
		PATCH_MESSAGE="patch_message.txt"
		readarray -t patchMessageArray < "${PATCH_MESSAGE}"

		local projectName="${patchMessageArray[0]}"
		local branchName="${patchMessageArray[1]}"
		local commitID="${patchMessageArray[2]}"
		local refs_change_id="${patchMessageArray[3]}"
		local parentsCommitId="${patchMessageArray[4]}"

		touch "projectNameExist.txt"
		PROJECT_NAME_EXIST="projectNameExist.txt"
		project_exist_or_not=$(grep "${projectName}" "${PROJECT_NAME_EXIST}")
		if [ "${project_exist_or_not}" == "" ] || [ -z "${project_exist_or_not}" ];then
			mkdir -p "${projectName}"
			pushd "${projectName}" > /dev/null
				echo -e "\e[32m we now at ${projectName} \e[0m"
                                git init && echo -e "\e[31m ============= first init ============\e[0m"
                                git remote add origin ssh://"${GERRIT_HOST}"/"${projectName}"
				git fetch origin "${branchName}" > /dev/null
				git reset --hard "origin/${branchName}"
				commit_id_exist
				do_patch "${commitID}" "${projectName}" "${parentsCommitId}"
                        popd > /dev/null
		else
			pushd "${projectName}" > /dev/null
				echo -e "\e[32m we now at ${projectName} \e[0m"
				branch_line=$(git branch | awk '{print NF}' | sed -n "/2/=")
				cmd="echo $branch_line"
				local_branch=$(git branch | sed -n "$($cmd)"p | awk '{print $2}')
				if [ "${local_branch}"  !=  "${branchName}" ];then
					git fetch origin "${branchName}" > /dev/null
					git checkout "${branchName}"
					git reset --hard "origin/${branchName}"
				fi

				commit_id_exist
				do_patch "${commitID}" "${projectName}" "${parentsCommitId}"
			popd > /dev/null
			echo -e "\e[32m we now leave ${projectName} \e[0m\n"	
		fi
		echo "${projectName}" >> projectNameExist.txt
	else
		echo -e "\e[31m no message about ${gerrit_change_id} in ${GERRIT_HOST} \e[0m"
		continue
	fi
done
}

function choice_do_patch(){
echo -e "\e[31m 通过BUG号打patch请输入b,\n 通过change_id 打patch请输入c\e[0m"
dir_exist_or_not ${PATCH_DIR} "yes"
read -r ANDD

case "${ANDD}" in
	b|B) local choice='b';;
	c|C) local choice='c';;
	*) exit 1;;
esac

if [ "${choice}" == "b" ];then
	clear_txt "${choice}"
	get_bug_project_and_commit_id
	deal_with_patch_log_file
elif [ "${choice}" == "c" ];then
	echo -e "\e[32m please enter 10 or 40 ,so we can select it!!!\e[0m"
	read -r CHOICE
	case "${CHOICE}" in
		1|10) get_changeId_message '192.168.10.10' ;;
		4|40) get_changeId_message '192.168.10.40' ;;
		*) get_changeId_message '192.168.10.10' ;;
	esac
else
	echo "system error"
	exit 1
fi
}
###############    main    ################
choice_do_patch
