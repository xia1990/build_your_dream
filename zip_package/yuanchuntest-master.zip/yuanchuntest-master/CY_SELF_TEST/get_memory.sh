#!/bin/bash
sed -n "/^#d/p" "$1"
