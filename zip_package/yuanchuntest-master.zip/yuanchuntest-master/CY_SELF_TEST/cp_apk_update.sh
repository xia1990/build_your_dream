cp_apk_to_hios(){
#now we are in source
#git clone ssh://192.168.10.40:29418/hios
pathroot=`pwd`
I=0
if [ -f cp_filenotfound.txt ];then
	rm -rf cp_filenotfound.txt
fi

while read source 
do
        I=`expr $I + 1`

        sed -n -e "`echo $I`p" dest.txt > raw.txt
        dest=`cat raw.txt`
	echo "cp $I files from $source to $dest "
	sleep 0.1s
		
        cp -rf $source $dest
        if [ $? != 0 ];then
        echo "$source file not exist" >> cp_filenotfound.txt
        fi
	cd ${dest}
	find -type l -name "*.so" -exec rm -rf {} \;
	find -type d | tee path_can_not_be_null
	echo "find type"
	
	while read path
	do
		cd $path
		touch file_must_exist_now
		cd -
	done < path_can_not_be_null	

	rm -rf path_can_not_be_null
	cd ${pathroot}
		
done < source.txt

cd  ./hios/
pwd
echo "now we delete"
find -name "file_must_exist_now" -exec rm -rf {} \;
echo "cp successful!"

cd ../
if [ -f cp_filenotfound.txt ];then
        echo -e  "\033[31msome files can not find in source ,you can see it ==>>cp_filenotfound.txt\033[0m"
fi
pwd
rm raw.txt

cd hios
git add .
#git commit -m "add apk"
#git push origin HEAD:master
}
cp_apk_to_hios
