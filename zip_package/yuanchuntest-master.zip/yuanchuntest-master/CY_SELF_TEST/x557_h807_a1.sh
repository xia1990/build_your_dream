#!/bin/bash
#this shell make repo code by cory

WEEKDAY=`date +%w`
branchName="X557_H807_XUI"
projectName="x557_h807_a1"
archiveDirectory="/X557_H807/A1_BOM"
manifestDirectory="x557_h807_release_tag"

lastDay=$(date +%Y%m%d -d "yesterday")
snapTime=$(date +%Y%m%d%H%M)
pathRoot=$(pwd)
archiveTime=$(date +%Y.%m.%d)
archiveTimeSecond=$(date +%Y.%m.%d.%M)
version=
readonly BASE_URL=ssh://192.168.10.10/MTK6580_M/manifest
readonly MANIFEST_BRANCH=master


checkenv()
{
    local SPACE=`df -h /dev/sda1 | sed -n '2p' | awk '{print $4}' | sed 's/G//g' `
    echo "compile_device space is ${SPACE}"
    if [ ${SPACE} -lt 100 ]; then
        echo -e "编译服务器空间不足"
    else
        echo -e "编译服务器空间良好"
    fi

        local SPACE=`df -h /mnt/SwVer | sed -n '2p' | awk '{print $4}' | sed 's/G//g' `
    echo "compile_device space is ${SPACE}"
    if [ ${SPACE} -lt 100 ]; then
        echo -e "版本归档服务器空间不足"
    else
        echo -e "版本归档服务器空间良好"
    fi
}



function update(){
#clean out the workspace and update the work

    rm -rf .* ./*	
    repo init -u ${BASE_URL} -b ${MANIFEST_BRANCH} -m $branchName.xml
    repo sync  -c -j24
    repo start $branchName --all
    repo sync -c 2>&1 | tee sync.log.txt
}

function modifyVersion(){
# add software version modify
cd rlk_projects/$projectName
sed -i "/MTK_BUILD_VERNO/s/[0-9]\{8\}/$lastDay/" ProjectConfig.mk
git add .
git commit -m " update version"
git pull --rebase
originBranch=`git config branch.$branchName.merge`
#git push origin HEAD:$originBranch
cd $pathRoot
}

fn_modify_version_number()					
{
	cd rlk_projects/${projectName}
	VERSION=`grep MTK_BUILD_VERNO ProjectConfig.mk | sed 's/ //g' | sed 's/.*=//g'`		
	ver1=`echo ${VERSION%-*}` 			
	ver_test=`echo ${ver1%-*}` 		
	ver2=`echo ${ver1##*-}` 		
	times_now=`echo ${ver2/X/}`		
	times_future=$((times_now+1)) 	

	sed -i "s/MTK_BUILD_VERNO = .*/MTK_BUILD_VERNO = ${ver_test}-X${times_future}-${lastDay}/" ProjectConfig.mk
	if [ $PIPESTATUS -eq 0 ];then
		echo "successful"
	else
		echo "fail to modified"
	fi
	git add .
	git commit -m " HIOSWY-0 ver ${ver_test}-X${times_future}-${LASTDAY}"
	cd -
}


function makeBin(){
if [ ${WEEKDAY} -eq 0 ];then
source rlk_setenv.sh $projectName
archiveTime=$(date +%Y.%m.%d)_ENG
else
source rlk_setenv.sh $projectName  user  
fi
make -j24 2>&1 | tee build.log

if [ ${PIPESTATUS[0]}   -ne 0  ]
then
echo "error compile"
java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "编译报错"
mkdir -p  /mnt/SwVer/$archiveDirectory/${archiveTime}_error
cp build.log /mnt/SwVer/$archiveDirectory/${archiveTime}_error
exit 1
fi
make  otapackage  2>&1 | tee otapackage.log
if [ ${PIPESTATUS[0]}   -ne 0  ] 
then
echo "error compile" 
java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "编译报错"
mkdir -p  /mnt/SwVer/$archiveDirectory/${archiveTime}_error 
cp otapackage.log /mnt/SwVer/$archiveDirectory/${archiveTime}_error
exit 1
fi

custom=`ls -l  out/target/product/ | awk ' /^d/  {print $NF}'`
version=`grep  "ro.mediatek.version.release"  out/target/product/$custom/system/build.prop|sed 's/ //g'|sed 's/.*=//g'`
}

function can_push(){
cd ${pathRoot} 
build=`grep "make completed successfully" build.log`
build_m=`echo $build` 
build_successful=`echo ${build_m// /;}` 
if [ ! -z ${build_successful} ];then
        cd rlk_projects/${projectName} 
        git push origin HEAD:${branchName} 
        cd -
fi
}

function addSnap(){
#add snapshot manifest.xml
versionBase=${version%-*}
snapVersion=$versionBase-$snapTime
repo manifest -r -o $snapVersion.xml
cd .repo/manifests
git pull --rebase
if [ ! -d  "$manifestDirectory"    ]
then
mkdir $manifestDirectory
fi
lastSnapXml=$(ls -t $manifestDirectory/$versionBase* | head  -n1)
cp $pathRoot/$snapVersion.xml $manifestDirectory                #h533_release_tag
git add .
git commit -m "add snapshot $snapVersion.xml"
git push origin HEAD:master
cd $pathRoot
}

function archive(){
if [ -e "release"  ]
then
rm -rf ./release
fi
mkdir release

#obtain the version nuber
versionTime=${version##*-}

#KK AP BP
cp ./out/target/product/$custom/obj/CGEN/APDB* ./release
if [ -e ./release/*_ENUM   ]
then
rm ./release/*_ENUM
fi
cp ./out/target/product/$custom/system/etc/mddb/BPLG* ./release

cp ./out/target/product/$custom/boot.img ./release
cp ./out/target/product/$custom/cache.img ./release
cp ./out/target/product/$custom/lk.bin ./release
cp ./out/target/product/$custom/logo.bin ./release
cp ./out/target/product/$custom/*_Android_scatter.txt ./release
cp ./out/target/product/$custom/preloader* ./release
cp ./out/target/product/$custom/recovery.img ./release
cp ./out/target/product/$custom/system.img ./release
cp ./out/target/product/$custom/userdata.img ./release
cp ./out/target/product/$custom/secro.img ./release
cp ./out/target/product/$custom/trustzone.bin ./release
cp ./out/target/product/$custom/kernel ./release
cp ./out/target/product/$custom/MBR* ./release
cp ./out/target/product/$custom/EBR* ./release
cp ~/workspace/RLK_UTIL/CheckSum_Gen.exe ./release
cp ~/workspace/RLK_UTIL/FlashToolLib* ./release
cd ./release
echo "\015" | wine CheckSum_Gen.exe
rm CheckSum_Gen.exe
rm FlashToolLib*
zip -m  $version.zip ./*
echo "============================="
printf "version is $version :\n"
cd -

if [ -e "track"  ]
then
rm -rf ./track
fi
mkdir track
cp ./out/target/product/$custom/obj/KERNEL_OBJ/vmlinux ./track
cp -r  ./out/target/product/$custom/symbols ./track
cp build/target/product/security/platform.pk8 ./track
cp build/target/product/security/platform.x509.pem ./track
cd ./track
zip -m  -r track.zip ./*
cd -

}


function file(){
if [ -d /mnt/SwVer$archiveDirectory/$archiveTime  ]
then
archiveTime=$archiveTimeSecond
fi
mkdir $archiveTime
cp -r ./release/$version.zip $archiveTime
cp -r ./track/track.zip $archiveTime
cp -r out/target/product/$custom/obj/PACKAGING/target_files_intermediates/*.zip $archiveTime
cp ./out/target/product/$custom/full_$custom*.zip  $archiveTime/Tcard_update_$versionTime.zip
cp ./out/target/product/$custom/system/build.prop ./$archiveTime
#cp -rf $archiveTime /mnt/SwVer$archiveDirectory
}

function repoLog(){
touch log.txt log_cm
CURRENT_SNAPSHOT=$manifestDirectory/$snapVersion.xml
repo diffmanifests $lastSnapXml ${CURRENT_SNAPSHOT} | awk '{if($3~/^from$/ && $2~/^changed$/ && $5~/^to$/ || $3~/^revision$/ && $2~/^at$/)print}' | awk '{print $1,$4,$6}' > log_cm
sed -i 's/refs\/tags\///g' log_cm
while read line
      do
       t1=`echo "$line" | awk  '{print $1}'`
       t2=`echo "$line" | awk  '{print $2}'`
       t3=`echo "$line" | awk  '{print $3}'`
       echo $t1
       echo $t2
       echo $t3
       cd $t1
       if [ ! -n "$t3" ];then
       git log  ${t2} --pretty="%an|%s" | grep -v "Merge" | awk -F\| '{printf("%-15s\t%s\n",$1, $2) }' >> ${pathRoot}/log.txt
       else
       git log  ${t2}..${t3} --pretty="%an|%s" | grep -v "Merge" | awk -F\| '{printf("%-15s\t%s\n",$1, $2) }' >> ${pathRoot}/log.txt
       fi
       cd ${pathRoot}
done < log_cm
sort -b -f -d -u ${pathRoot}/log.txt -o ${pathRoot}/log.txt

cp log.txt ./$archiveTime
mv $snapVersion.xml ./$archiveTime
cp ./$archiveTime /mnt/SwVer$archiveDirectory -rf
repo abandon  $branchName
}

function message(){
linuxWholeDir="$archiveDirectory/$archiveTime"
winWholeDir=$(echo $linuxWholeDir | tr '/' '\\')
echo -e "\033[31mVersion: $version\033[0m"
echo -n -e '\033[31mArchiveDirectory: \\\\192.168.1.75\SwVer'
echo -e "\033[31m$winWholeDir\033[0m"
java -jar ~/workspace/RLK_UTIL/FeiQ.jar  "Version: $version
ArchiveDirectory: \\\\192.168.1.75\SwVer$winWholeDir"

}


checkenv
if [[ !  "$archiveDirectory"  =~ "OTATEST"  ]] && [[ !  "$archiveDirectory"  =~ "otatest"     ]]
then
update
modifyVersion
fn_modify_version_number
makeBin
can_push
addSnap
archive
file
repoLog
else
update
sed -i "/MTK_BUILD_VERNO/s/[0-9]\{8\}/OTATEST/" rlk_projects/$projectName/ProjectConfig.mk
makeBin
cp -r out/target/product/$custom/obj/PACKAGING/target_files_intermediates/*.zip /mnt/SwVer$archiveDirectory
fi
#message
