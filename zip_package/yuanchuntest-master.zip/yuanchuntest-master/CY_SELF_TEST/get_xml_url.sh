#!/bin/bash
function get_default_args(){
XML_FILE=$1
defaultArray=($(sed -n "/default/p" "$XML_FILE"))
for str in "${defaultArray[@]}"
do
	remote_line=$(echo "$str" | grep "remote")
	if [ ! -z "$remote_line" ];then
		defalut_origin=$(echo "$remote_line" | awk -F '"|"' '{print $2}')
		echo "$defalut_origin"
		break
	fi
done

fetchArray=($(sed -n "1,5p" "$XML_FILE" | sed -n "/fetch/p" | grep "name=\"$defalut_origin\""))
for ss in "${fetchArray[@]}"
do
	ssh_line=$(echo "$ss" | grep "fetch")
	if [ ! -z "$ssh_line" ];then
		fetch_url=$(echo "$ssh_line" | awk -F '"|"' '{print $2}')
		echo "$fetch_url"
		break
	fi
done
}

get_default_args "$1"
