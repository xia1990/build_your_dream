#!/bin/bash
A=B
echo "PID for 1.sh before exec/source/fork: $$"
export A
echo "1.sh:\$A is $A"
case $1 in 
exec) echo "using exec..." 
exec ./2.sh 2>&1;;
source) echo "using source..."
. ./2.sh;;
fork) echo "using fork by default..."
./2.sh;;
esac
echo "PID for1.sh after exec/source/fork: $$"
echo "1.sh: \$A is $A"
