#!/bin/bash
ALL_START_TIME=$(date +%s) #从 1970年1月1日0点0分0秒到现在历经的秒数
readonly BASE_URL=$1 #manifest仓库地址
readonly MANIFEST_BRANCH=master #manifest仓库分支
readonly XML_NAME=$2 #清单名称
readonly NEW_BRANCH=$3 #新分支名称
readonly args_number=$# #参数个数
return_value="" #接受判断10_origin关键字是否存在的返回值。存在为1，不存在为0
GC="no" #判断是否拉共仓分支的变量。默认是no,在agrs_exist函数中，判断要拉共仓时，会改为yes
PATHROOT=$(pwd)
shift 3

#定制输出文字颜色的函数
function echo_output(){
        string=$1
        color=$2
        if [ -z ${color} ];then
                color=32
        fi

        echo -e "\e[${color}m${string}\e[0m"
}

#判断参数个数为0就退出的函数
function agrs_exist(){
if [ $# -eq 0 ];then #判断的是这个函数的参数个数，肯定不等于0的。因为下面传了一个参数。这里写的没有意义。
        echo_output "no args"
        exit 1
fi

local args_numbers=$1
	if [ "$args_numbers" -lt 3 ];then #参数个数小于3个，提示并退出。
		echo_output "Useage :`basename $0` ssh://192.168.10.10/MTK6753/manifest X601_H536_XUI.xml NEW_BRANCH_NAME GC_BRANCH_NAME1 GC_BRANCH_NAME2 ..." 35
		exit 0
	fi
#TODO
	if [ "$args_numbers" -ge 4 ];then #参数个数大于等于4个,进行共仓拉分支确认。
		echo "Do you really want to pull gongcang branch?"
		while :
		do
			read -p "Enter yes or no (exit to exit): " ANS
			case $ANS in
				y|Y|yes|Yes|YES) echo "you enter yes"
				GC="yes" #
				break ;;
				n|N|no|No|NO) echo "you enter no" 
				break ;;
				exit) exit ;;
				*) echo "please enter yes or no !!!"
			esac
		done
	fi
}

#共仓清单处理函数。
function xml_gc_modified(){
if [ $# -eq 0 ];then #传入的共仓分支参数
	echo_output "function xml_gc_modified no args"
fi
if [ -d ".repo/manifests" ];then 
        cd .repo/manifests
	git clean -dfx
	git reset --hard
        for loop #用函数的参数在默认清单中循环搜索和共仓分支相关的行。
        do
                grep "$loop\>" ${XML_NAME} >> HIOS.txt
        done

        sed -n "1,/default/"p ${XML_NAME} > HEAD.txt
        sed -n "$"p ${XML_NAME} > TAIL.txt
        cat HEAD.txt HIOS.txt TAIL.txt > HIOS.xml #重构一个清单文件。
        git add HIOS.xml #不add也可以拉。。。。
        git commit -m "add HIOS.xml"
        cd -
fi
}

function get_source_code(){
if cd ${PATHROOT};then #进入代码目录。
	if [ "$GC" = "no" ];then #当不拉共仓分支时，正常拉代码。
		if repo init -u ${BASE_URL} -b ${MANIFEST_BRANCH} -m ${XML_NAME} | tee init.log 2>&1;then
			if repo sync  -c -j16 | tee  sync.log 2>&1;then
		        	echo_output "stop to download the source"
			else
				exit 1
			fi
		else
			exit 1
		fi
	else #当拉共仓分支时，先repo init 一下，修改清单文件。用修改之后的清单拉代码。
               	if repo init -u ${BASE_URL} -b ${MANIFEST_BRANCH} -m ${XML_NAME} | tee init.log 2>&1;then
			xml_gc_modified $@ #传的参数是shift 3之后只剩下共仓分支的那部分参数。
			if repo init -m HIOS.xml | tee ini.lot 2>&1;then #用得到的清单拉代码。
				if repo sync -j16 | tee sync.log 2>&1;then
					echo_output "sync code successful"
				else
					echo_output "sync code failed!!!" 31
					exit 1
				fi
			else
				echo "HIOS.xml fail"
				exit 1
			fi	
                else
               	        exit 1
                fi
	fi
else
	exit 1
fi
10_origin_exist
return_value=$?
}

function start_new_branch(){
if [ $# -eq 0 ];then #新分支名称。原先默认分支名称和清单名称一致。现在可能要独立作为两个参数输入了。
        echo_output "no args"
        exit 1
fi

be_start_branch=$1
if repo start ${be_start_branch} --all ;then
	echo_output "start new branch successful!"
else
	echo_output "start new branch failed!" 31
	exit 1
fi
}

function 10_origin_exist(){
if cd ${PATHROOT};then
	if [ -f ".repo/manifest.xml" ];then
		exist_10="`grep "10_origin\>" ./.repo/manifest.xml`"
		guodu1=`echo $exist_10`
		exist_10=`echo ${guodu1// /;}`
		if [ ! -z ${exist_10} ];then
			return 0
		else
			return 1
		fi
	else
		echo_output "no manifest.xml.path or code wrong!" 31
		exit 1
	fi
else
	echo_output "path wrong!" 31
	exit 1
fi
}

#判断有没有10_origin 关键字的函数
function push_new_branch(){
#user the value of 10_origin_exist
if [ $return_value -eq 0 ];then
	repo forall -c git push origin $NEW_BRANCH
	repo forall -c git push 10_origin $NEW_BRANCH
	echo_output "10_origin exist;we push $NEW_BRANCH to origin & 10_origin!"
else
	if repo forall -c git push origin $NEW_BRANCH;then
                echo_output "new branch push successful!"
        else
                echo_output "new branch push failed!"
		exit 1
        fi
	echo_output "10_origin do not exist;we push $NEW_BRANCH to origin!"
fi
}

#推送清单的函数
function push_xml(){
#push the xml to manifest.git
be_push_file=$1
if [ -d ".git/" ];then
	branch=`git branch | awk '{print $2}'`
	origin_branch=`git config branch.${branch}.merge`
	git add ${be_push_file}
        git commit -m "add ${be_push_file}"
        git pull
	git push origin HEAD:${origin_branch}
	git clean -dfx
	git reset --hard 
else
	echo_output "path wrong!!!" 31
	exit 1
fi
}

function xml_modified(){
#modified xml for new branch
if cd $PATHROOT/.repo/manifests/ ;then
	if [ -s ${XML_NAME} ];then #文件不为空执行
		if cp ${XML_NAME} ${NEW_BRANCH}.xml;then #cp一份新的xml
			if [ ${return_value} -ne 0 ];then #当10_origin不存在时。
				#########
				if [ "${GC}" = "no" ];then #当不拉共仓时，直接sed修改一下就可以了。
                                	if sed -i "s/revision=\".*\"/revision=\"`echo $NEW_BRANCH`\"\ /g" ${NEW_BRANCH}.xml;then
						if push_xml "${NEW_BRANCH}.xml";then
							echo_output "push ${NEW_BRANCH}.xml successful!"
						else
							echo_output "push failed!!!" 31
							exit 1
						fi
					else
						echo_output "xml modified failed!!!" 31
						exit 1
					fi
				else #当拉共仓时，因为上面，xml_gc_modified中有add和commit操作。所以下面要回退掉。其实完全可以不add和commit。
					git reset --hard HEAD^ #delete HIOS.xml after push branch
					for loop #将所有共仓分支修改小。其余的不动。
					do
						if sed -i "s/revision=\"`echo $loop`\"/revision=\"`echo $NEW_BRANCH`\"\ /g" ${NEW_BRANCH}.xml;then
							if push_xml "${NEW_BRANCH}.xml";then
                                                	        echo_output "push ${NEW_BRANCH}.xml successful!"
                                           	    	else
                                                        	echo_output "push failed!!!" 31
	                                                        exit 1
        	                                        fi
                                        	else
                                                	echo_output "xml modified failed!!!" 31
	                                                exit 1
        	                                fi
					done
				fi
				#########
			elif [ ${return_value} -eq 0 ];then #当有10_origin关键字时。
				#########
				if [ "${GC}" = "no" ];then #当不需要拉共仓时。
					sed -n "/remote=\"10_origin\"/=" ${NEW_BRANCH}.xml > remote_line.txt #记录一下10_origin关键字的行数。
					sed -i "s/revision=\".*\"/revision=\"`echo $NEW_BRANCH`\"\ /g" ${NEW_BRANCH}.xml #全局修改清单。

					while read line
					do #因为上面的操作会覆盖掉，10_origin关键字。下面在指定行插入10_origin。
						sed -i "`echo $line`s/revision=\".*\"/& remote=\"10_origin\"/g" ${NEW_BRANCH}.xml
					done < remote_line.txt

                               	        if push_xml "${NEW_BRANCH}.xml";then
                                      	        echo_output "push ${NEW_BRANCH}.xml successful!"
	                                else
        	                        	echo_output "push failed!!!" 31
						exit 1
					fi
				else #当需要拉共仓时,下面的方法有遗漏，没有写出当需要拉共仓并且有10_origin关键字的情况。建议统一记录所有remote="10_origin行，再删除，然后再插入remote="10_origin""
					git reset --hard HEAD^ #delete HIOS.xml after push branch
					for loop
					do
						if sed -i "s/revision=\"`echo $loop`\"/revision=\"`echo $NEW_BRANCH`\"\ /g" ${NEW_BRANCH}.xml;then
						#上面的操作可能会覆盖掉10_origin关键字。需要重新写入。
                                                        if push_xml "${NEW_BRANCH}.xml";then
                                                                echo_output "push ${NEW_BRANCH}.xml successful!"
                                                        else
                                                                echo_output "push failed!!!" 31
                                                                exit 1
                                                        fi
                                                else
                                                        echo_output "xml modified failed!!!" 31
                                                        exit 1
                                                fi
					done	
				fi
				##########
			else
				echo "wrong value of return_value!!!" 31
				exit 1
			fi
		else
			echo_output "cp ${XML_NAME} ${NEW_BRANCH} failed!" 31
			exit 1
		fi
	else
		exit 1
	fi
else
	echo_output "cd to xml path failed!" 31
fi
cd $PATHROOT
}

#计时函数
function time_count(){
#count pull branch time
ALL_END_TIME=$(date +%s)
ALL_DIFF=$(( $ALL_END_TIME - $ALL_START_TIME ))
COMPILE_MINUTE=`echo "scale=1;${ALL_DIFF}/60" | bc`
echo_output "本次分支拉取耗时： ${COMPILE_MINUTE}分钟"

}

#拉取测试函数
function new_branch_pull_test(){
cd $PATHROOT
if repo init -u ${BASE_URL} -b ${MANIFEST_BRANCH} -m ${NEW_BRANCH}.xml;then
	if repo sync  -c -j16 | tee  sync.log 2>&1;then
		echo_output "new branch can be pull "
	else
		echo_output "some project can not be pull !!!" 31
	fi
fi
}

####################### main code #####################
agrs_exist $args_number
get_source_code $@
start_new_branch ${NEW_BRANCH}
push_new_branch
xml_modified $@
#new_branch_pull_test
time_count
