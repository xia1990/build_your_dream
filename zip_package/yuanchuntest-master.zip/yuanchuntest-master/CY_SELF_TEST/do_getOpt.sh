#!/bin/bash
function do_getopt(){
	while getopts abc: OPTION
	do
		case $OPTION in
			a) echo "only a" ;;
			b) echo "only b" ;;
			c) local carg=$OPTARG
			echo "$carg" ;;
		esac
	done
}
if [ $# -gt 0 ]
then
	do_getopt $@
fi
