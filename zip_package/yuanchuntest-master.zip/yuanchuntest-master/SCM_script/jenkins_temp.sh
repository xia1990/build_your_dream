#!/bin/bash
readonly SCRIPTDIR="$(cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd)"
release_stript='release_version_new.sh'
ROOT=$(pwd)
MY_NAME=$(whoami)
TODAY=$(date +%Y%m%d)
Random="$RANDOM"
HOST_NAME_ARRAY=(SOFT35-11 SOFT35-12 SOFT35-14 SOFT35-15 SOFT35-16 SOFT35-17 SOFT35-18)
mirror_path_array=('/home/jenkins/mirror' '/home/jenkins/mirror' '/home1/SW3/mirror' '/home1/SW3/mirror' '/home1/SW3/mirror' '/home/jenkins/mirror' '/home/jenkins/mirror')

readonly OPTION_VAR_ARRAY=(
    CODE_URL
    CODE_BRANCH
    CODE_XML
    PROJECT_NAME
    VARIANT
    PROJECT_BUILD_NAME
    SAVE_TYPE
    IN_VER
    OUT_VER
    INCRE_VER
    DEBUG_MOD
)


function blank_check(){
    local var="$1"
    local kongge1_check=$(echo -n "$var" | grep " ")
    if [[ "$kongge1_check"  != "" || ! -z "$kongge1_check" ]]
    then
        echo "error ,blank space in $var"
        exit 1
    fi
}

function parse_option(){
    echo "parse_option"
    mkdir CODE  > /dev/null 2>&1
    while [[ $# -gt 1 ]]
    do
        key="$1"
        case "$key" in
            --code-url)
                readonly CODE_URL=$(echo "$2"| sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check code url"
                ;;
            --code-branch)
                readonly CODE_BRANCH=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check code branch"
                ;;
            --code-xml)
                readonly CODE_XML=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check code xml"
                ;;
            --project-name)
                readonly PROJECT_NAME=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')      # E260L E296L
                echo "check project name"
                ;;
            --variant)
                readonly VARIANT=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')   # eng  user
                echo "check variant"
                ;;
            --project-build-name)
                readonly PROJECT_BUILD_NAME=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')  #E260L_WW ZB500TL_CMCC
                echo "check project build name"
                #check_args 'ZB500TL ZB500TL_CMCC ZB500TL_CTCC E260L E260L_CMCC E260L_CTCC E260L_CTCERT E260L_WW E262L E262L_CMCC E262L_CTCC E262L_WW D281L_US E286L_CMCC' "$PROJECT_BUILD_NAME"
                readonly PROJECT_BUILD_NAME_FIELD=$(echo "$PROJECT_BUILD_NAME" | awk -F "_" '{print NF}')
                if [ "$PROJECT_BUILD_NAME_FIELD" -ge 1 ]
                then
                    readonly OUT_PROJECT_NAME=$(echo "$PROJECT_BUILD_NAME" | awk -F "_" '{print $1}')
                    BUILD_PROJECT_NAME_END=$(echo "$PROJECT_BUILD_NAME" | awk -F "_" '{print $2}')
                    if [[ "$BUILD_PROJECT_NAME_END" == "" || -z "$BUILD_PROJECT_NAME_END" ]]
                    then
                        readonly BUILD_PROJECT_NAME_END="driveonly"
                    fi
                    echo "$OUT_PROJECT_NAME $BUILD_PROJECT_NAME_END"
                fi
                ;;
            --save-type)
                readonly SAVE_TYPE=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check save type"
                ;;
            --soft-ver)
                readonly SOFT_VER=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check soft ver"
                readonly IN_VER=$(echo "$SOFT_VER" | awk '{print $1}')
                readonly OUT_VER=$(echo "$SOFT_VER" | awk '{print $2}')
                readonly INCRE_VER=$(echo "$SOFT_VER" | awk '{print $3}')
                echo "$IN_VER \n  $OUT_VER \n $INCRE_VER"
                ;;
            --sign)
                readonly SIGN_FLAG=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check sign flag"
                ;;
            --wind-asusset-ver)
                readonly ASUSSETTING_VER=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check asussetting ver"
                ;;
            --otapackage)
                readonly OTA_PACKAGE=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check otapackage"
                ;;
            --cid)
                readonly CID=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check cid"
                ;;
            --debug-mod)
                readonly DEBUG_MOD=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "check debug-mod"
                ;;
            --snapshot)
                readonly UPLOAD_SNAPSHOT=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "upload snapshot"
                ;;
            --wait-build)
                readonly WAIT_BUILD=$(echo "$2" | sed 's/^[ \t]*//g'| sed 's/[ \t]*$//g')
                echo "wait build"
                ;;
            *)
                echo "error"
                exit 1
                ;;
        esac
        shift;shift
    done
    
    for myvar in "${OPTION_VAR_ARRAY[@]}"
    do
        eval "[ -z \${${myvar}+x} ]"
        if [ "$?" == 0 ]
        then
            echo "args empty"
            exit 1
        fi
    done
}


function download_code(){
    echo "download_code"
    local mirror_path=""
    mirror_path_len="${#mirror_path_array[@]}"
    host_name_len="${#HOST_NAME_ARRAY[@]}"
    if [ "$mirror_path_len" == "$host_name_len" ]
    then
        local seq_len=$((mirror_path_len - 1))
        for i in `seq 0 $seq_len`
        do
            if [ "$HOSTNAME" == "${HOST_NAME_ARRAY[$i]}" ]
            then
                readonly mirror_path="${mirror_path_array[$i]}"
                break
            fi
        done
    fi
    
    pushd "$ROOT/CODE"
        case "$PROJECT_NAME" in
            E260L|E262L|E286L|E266L)
                if [ -d "${mirror_path}/260_mirror_repo" ]
                then
                    pushd "${mirror_path}/260_mirror_repo"
                        repo sync  || repo sync || repo sync
                    popd
                    echo "" | repo init -u "$CODE_URL" -b "$CODE_BRANCH" -m "$CODE_XML" --reference="${mirror_path}/260_mirror_repo"
                    [ $? != 0 ] && echo "error, repo init failed" && exit 1
                else
                    echo "" | repo init -u "$CODE_URL" -b "$CODE_BRANCH" -m "$CODE_XML"
                    [ $? != 0 ] && echo "error, repo init failed" && exit 1
                fi
                ;;
            *)
                echo "" | repo init -u "$CODE_URL" -b "$CODE_BRANCH" -m "$CODE_XML"
                [ $? != 0 ] && echo "error, repo init failed" && exit 1
                ;;
        esac
            repo sync -j8 || sleep 60s && repo sync -j8 || sleep 60s && repo sync -j8
            [ $? != 0 ] && echo "error, repo sync failed" && exit 1
            repo start "$CODE_BRANCH" --all
    popd
}

function new_project_info(){
        case "$SAVE_TYPE" in
        "preofficial" | "factory" | "temp")
            echo "type=${SAVE_TYPE}" > ~/project.info
            echo "project=${PROJECT_NAME}" >> ~/project.info
            echo "custom=${BUILD_PROJECT_NAME_END}" >> ~/project.info
            if [ -d "/jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"$BUILD_PROJECT_NAME_END"/"$IN_VER"" ]
            then
                echo "version=${IN_VER}_${Random}" >> ~/project.info
            else
                echo "version=${IN_VER}" >> ~/project.info
            fi
            ;;
        "dailybuild")
            echo "type=${SAVE_TYPE}" > ~/project.info
            echo "project=${PROJECT_NAME}" >> ~/project.info
            echo "custom=${BUILD_PROJECT_NAME_END}" >> ~/project.info
            if [ -d "/jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"${BUILD_PROJECT_NAME_END}_dailybuild"/"$TODAY"" ]
            then
                echo "version=${TODAY}_${Random}" >> ~/project.info
            else
                echo "version=${TODAY}" >> ~/project.info
            fi
            echo "option=custom:${BUILD_PROJECT_NAME_END}_dailybuild" >> ~/project.info
            ;;
        esac
}

function build_code(){
    echo "build_code"
    pushd "$ROOT/CODE"
        rm ~/project.info
        echo "" >> input.txt
        #这里写quick_build.sh编译命令

        local -r success=$(tail build-log/build.log  | grep "success")
        [[ "$success" == "" || -z "$success" ]] && echo "code build error!!!" && exit 1

        rm input.txt
        rm /data/mine/"test"/"MT6572"/"$MY_NAME"/*
        rm -rf /tmp/*
        echo "sleep 30s" && sleep 30s #预防之前释放的文件删除之后继续释放
    popd
}


function modified_sign_UL(){
    local -r old_value="$1"
    local -r new_value="$2"
    pushd "${ROOT}/CODE"
        pushd "out/target/product/${OUT_PROJECT_NAME}/"
            local UL_old_name=$(ls full* -t | head -1 )
            rm -rf ota_back_dir && mkdir ota_back_dir
            cp "$UL_old_name" ota_back_dir

            rm -rf META-INF/ && mkdir -p META-INF/com/google/android/
            unzip -j "$UL_old_name" 'META-INF/com/google/android/updater-script' -d "META-INF/com/google/android/"
            sed -i "s/$old_value/$new_value/g" "META-INF/com/google/android/updater-script"
            if [ "$?" != 0 ]
            then
                echo "error: modified 260 ul sign failed"
                return 1
            fi
            zip "$UL_old_name" -f 'META-INF/com/google/android/updater-script'
            if [ "$?" != 0 ]
            then
                echo "error: zip 260 ul sign failed"
                rm -rf "$UL_old_name" && mv ota_back_dir/"$UL_old_name" . && rm -rf ota_back_dir
                return 1
            fi
            mv "$UL_old_name" "${ROOT}/CODE"
            rm -rf META-INF
        popd

        sign_tool=out/host/linux-x86/framework/signapk.jar
        sign_key1=device/mediatek/common/security/"$OUT_PROJECT_NAME"/releasekey.x509.pem
        sign_key2=device/mediatek/common/security/"$OUT_PROJECT_NAME"/releasekey.pk8
        echo "please wait..."
        file_name=$(echo "$UL_old_name" | sed -r 's/\.zip$//i')
        java -Djava.library.path=out/host/linux-x86/lib64 -jar $sign_tool -w $sign_key1 $sign_key2 $UL_old_name ${file_name}_signed.zip
        echo "sign $file to ${file_name}_signed.zip done"
        echo "All done."
        mv ${file_name}_signed.zip out/target/product/E260L/"$UL_old_name"
    popd
}


function release_version(){
echo "release_version"
if [ "$DEBUG_MOD" == "false" ]
then
    :
    #这里写release_version.sh脚本释放命令
else
    echo "do not release_anyfile"
fi
}


function version_back_up(){
    if [ -d "/home1/SW3/" ]
    then
        mkdir -p /home1/SW3/version_back_up
        if [ -d "/home1/SW3/version_back_up" ]
        then
            mkdir -p /home1/SW3/version_back_up/"${PROJECT_NAME}_${TODAY}_${Random}"
            cp '/data/mine/test/MT6572/jenkins/'* /home1/SW3/version_back_up/"${PROJECT_NAME}_${TODAY}_${Random}"/
        else
            echo "version back up failed"
        fi
    fi
}


function md5_check_file(){
    echo "md5_check_file"
    pushd "$ROOT/CODE"
        local status="true"
        local -r DEST_DIR=$(cat ~/project.info  | grep version | head -1 | awk -F "=" '{print $2}')
        while "$status"
        do
           case "$SAVE_TYPE" in
               "preofficial" | "factory" | "temp")
                   ls -al /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"$BUILD_PROJECT_NAME_END"/"$DEST_DIR" | tee same_state1
                   sleep 20s
                   ls -al /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"$BUILD_PROJECT_NAME_END"/"$DEST_DIR" | tee same_state2
                   ;;
               "dailybuild")
                   ls -al /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"${BUILD_PROJECT_NAME_END}_dailybuild"/"$DEST_DIR" | tee same_state1
                   sleep 20s
                   ls -al /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"${BUILD_PROJECT_NAME_END}_dailybuild"/"$DEST_DIR" | tee same_state2
                   ;;
               *)
                   echo "error,do not support $SAVE_TYPE"
                   exit 1
                   ;;
           esac
           local state1=$(md5sum same_state1 | awk '{print $1}')
           local state2=$(md5sum same_state2 | awk '{print $1}')
           if [ "$state1" == "$state2" ]
           then
               status="false"
               rm same_state1 same_state2
           fi
        done
        
        case "$SAVE_TYPE" in
            "preofficial" | "factory" | "temp")
            pushd  /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"$BUILD_PROJECT_NAME_END"/"$DEST_DIR"
            ;;
            "dailybuild")
            pushd  /jenkins/"$SAVE_TYPE"_version/"$PROJECT_NAME"/"${BUILD_PROJECT_NAME_END}_dailybuild"/"$DEST_DIR"
            ;;
            *)
            echo "error,do not support $SAVE_TYPE"
            exit 1
            ;;
        esac
            if [ -s "checklist.md5" ]
            then
                md5sum -c checklist.md5
            fi
            popd
    popd
}


function do_snapshot(){
    echo "do_snapshot"
    pushd "$ROOT"/CODE
        repo manifest -ro "manifest-${IN_VER}_${TODAY}.xml"
        md5sum -b "manifest-${IN_VER}_${TODAY}.xml" | tee -a "out/target/product/$OUT_PROJECT_NAME/checklist.md5"
        cp manifest-* /data/mine/"test"/"MT6572"/"jenkins"/
        cp "out/target/product/$OUT_PROJECT_NAME/checklist.md5" /data/mine/"test"/"MT6572"/"jenkins"
    popd
}


function wait_build(){
    if [ "$WAIT_BUILD" == "true" ]
    then
        echo "wait_build"
        pushd "${ROOT}/CODE"
            while true
            do
                echo "we are wating now !!!" && sleep 20s
                if [ -f "startbuild" ]
                then
                    break
                fi
            done
        popd > /dev/null
    fi
}
#####main####
parse_option "$@" #参数解析
download_code #下载代码 
wait_build #等待编译,提供手动修改的时间
build_code #开始编译
new_project_info #新建 释放配置文件 ~/project.info
release_version #释放版本
if [ "$DEBUG_MOD" == "false" ]
then
    do_snapshot
    md5_check_file
else
    echo "do not do snapshot"
fi
