#!/bin/bash

S102X_URL="ssh://10.0.30.10:29418/LNX_LA_MSM8917_S102X_PSW/Manifest" 
S102X_MIRROR_URL="/EXCHANGE/mirror/S102X_MIRROR_REPO"
S102X_BRANCH_LIST=$1

function sync_code(){
    repo init -u $S102X_URL -m manifest.xml -b $S102X_BRANCH_LIST --reference=$S102X_MIRROR_URL --repo-url="git://10.0.30.4/git-repo.git" --no-repo-verify
    sed  -i "s/itadmin\@//g" .repo/manifests/manifest.xml
    repo sync -cj4
}

####################################
if [ $# == 1 ];then
    sync_code $S102X_BRANCH
else
    echo "请输入您要拉取代码分支的名称"
fi

